package esi.automation.recorder;

import java.util.ArrayList;
import java.util.List;

public class JsonList {

	
	private List<InputObject> listInputObjects;
	
	public List<InputObject> getListInputObjects() {
		if(listInputObjects==null){
			listInputObjects=new ArrayList<InputObject>();
			
		}
		return listInputObjects;
	}
}
