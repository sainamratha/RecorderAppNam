package esi.automation.recorder;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import org.apache.log4j.Logger;

import com.jagacy.AbstractSession;
import com.jagacy.Field;
import com.jagacy.Session3270;
import com.jagacy.ui.AbstractPanel;
import com.jagacy.ui.AbstractSwing;
import com.jagacy.ui.KeyAction;
import com.jagacy.ui.Panel3270;
import com.jagacy.util.I18n;
import com.jagacy.util.JagacyException;
import com.jagacy.util.LinkedHashMap;

import esi.automation.home.utils.AutomationUtils;

public class Emulator extends AbstractSwing {

	private static final long serialVersionUID = 8831901593363366980L;

	private static final ImageIcon ICON = new ImageIcon(
			Emulator.class.getResource("book.jpg"));

	private LinkedHashMap myLookAndFeelMap = new LinkedHashMap();

	private boolean myIsCancelled;

	private AbstractSession mySession;
	private JsonList jsonList;
	Properties props = new Properties();
	static Logger log = Logger.getLogger(Emulator.class);

	/**
	 * Creates the GUI.
	 * 
	 * @throws JagacyException
	 *             If an error occurs.
	 */
	private Emulator() throws JagacyException {
		super("JsonRecorder");

		UIManager.LookAndFeelInfo[] lafs = UIManager.getInstalledLookAndFeels();

		for (int i = 0; i < lafs.length; i++) {
			UIManager.LookAndFeelInfo laf = lafs[i];
			myLookAndFeelMap.put(laf.getName(), laf.getClassName());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.ui.AbstractSwing#createSession(java.lang.String)
	 */
	@Override
	protected AbstractSession createSession(String name) throws JagacyException {
		jsonList = new JsonList();
		mySession = new JsonRecorder(name, this, jsonList);
		return mySession;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.ui.AbstractSwing#createPanel()
	 */
	@Override
	protected AbstractPanel createPanel() throws JagacyException {
		return new Panel3270(this) {
			private static final long serialVersionUID = 299834078527771447L;

			@Override
			public void processKey(KeyEvent paramKeyEvent) {
				super.processKey(paramKeyEvent);

				LinkedHashMap A = getKeyMap();
				KeyAction localKeyAction = (KeyAction) A.get(KeyStroke
						.getKeyStrokeForEvent(paramKeyEvent));

				try {
					props.load(this.getClass().getClassLoader()
							.getResourceAsStream("functionalKeys.properties"));
					String[] keyList = props.getProperty("keys").split(",");
					List<String> functList = Arrays.asList(keyList);

					if (localKeyAction != null
							&& functList.contains(localKeyAction.toString())) {
						captureEvents(localKeyAction);

					}
				} catch (JagacyException e) {
					log.error("MyEmulator Error" + e.getMessage());
				} catch (IOException e) {
					log.error("MyEmulator Error" + e.getMessage());
				} catch (Exception e) {
					log.error("MyEmulator Error" + e.getMessage());
				}

			}

		};
	}

	/**
	 * @param localKeyAction
	 * @throws Exception
	 */
	public void captureEvents(KeyAction localKeyAction) throws Exception {
		Session3270 localSession3270 = (Session3270) getSession();

		Field[] arrayOfField = null;

		arrayOfField = localSession3270.readFields();
		Field field = null;
		for (int i = 0; i < arrayOfField.length; i++) {
			InputObject object = new InputObject();
			field = arrayOfField[i];
			log.info(field);
			field.setShowHidden(true);
			boolean isBefore = false;
			Pattern p = Pattern.compile(".*([01]?[0-9]|2[0-3]):[0-5][0-9].*");
			if (field.isModified()) {
				String fieldValue = "";
				Field fieldAfter = null;
				if (arrayOfField.length > i + 1) {
					fieldAfter = arrayOfField[i + 1];
				}

				Field fieldBefore = arrayOfField[i - 1];
				if (field.getRow() != fieldBefore.getRow()
						&& fieldAfter != null
						&& !fieldAfter.getValue().trim().isEmpty()) {
					fieldValue = fieldAfter.getValue();
					isBefore = true;
				} else {
					fieldValue = fieldBefore.getValue();
					fieldAfter = null;
				}

				if (fieldBefore.isProtected()
						|| (fieldAfter != null && fieldAfter.isProtected())) {
					String label = String.valueOf(fieldValue.trim());
					Matcher m = p.matcher(label);
					Boolean delimiter = true;
					char[] charLabel = label.toCharArray();
					for (int j = 0; j < charLabel.length && delimiter; j++) {
						if (charLabel[j] == 166) {
							delimiter = false;
							break;
						}
					}
					if (!field.isVisible()
							&& !field.getValue().trim().isEmpty()) {
						object.addinput("label",
								String.valueOf(fieldValue.trim()));
						object.addinput("position", "after");
						if (fieldValue.toLowerCase().contains("password")) {
							String encodedPwd = AutomationUtils.encodePwd(field
									.getValue().trim());
							object.addinput("value", encodedPwd);
							object.addinput("encoded", true);
						} else {
							object.addinput("value", "");
						}

						jsonList.getListInputObjects().add(object);
					} else if (!field.getValue().trim().isEmpty()
							&& !fieldValue.trim().isEmpty()
							&& (!m.matches() && delimiter)) {
						if (fieldValue.trim().matches("[0-9].*")) {
							fieldValue = AutomationUtils.numberCheck(fieldValue
									.trim());
						}
						object.addinput("label",
								String.valueOf(fieldValue.trim()));
						object.addinput("value", field.getValue().trim());
						if (isBefore) {
							object.addinput("position", "before");
						} else {
							object.addinput("position", "after");
						}

						jsonList.getListInputObjects().add(object);

					} else if (!field.getValue().trim().isEmpty()) {
						object.addinput("row", Integer.valueOf(field.getRow()));
						object.addinput("column",
								Integer.valueOf(field.getColumn()));
						object.addinput("value", field.getValue().trim());

						jsonList.getListInputObjects().add(object);
					}
				} else {
					object.addinput("row", Integer.valueOf(field.getRow()));
					object.addinput("column",
							Integer.valueOf(field.getColumn()));
					object.addinput("value", field.getValue().trim());
					jsonList.getListInputObjects().add(object);

				}

			}

		}

		InputObject objectOne = new InputObject();
		objectOne.addinput("keyname", localKeyAction.toString());
		jsonList.getListInputObjects().add(objectOne);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.ui.AbstractSwing#getProductName()
	 */
	@Override
	protected String getProductName() {
		return "MyEmulator";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.ui.AbstractSwing#getIcon()
	 */
	@Override
	protected ImageIcon getIcon() {
		return ICON;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.ui.AbstractSwing#connect()
	 */
	@Override
	protected boolean connect() {
		boolean connected = false;
		try {
			mySession.open();
			connected = true;
		} catch (JagacyException e) {
			AbstractSwing.printExceptions(e);
		}

		return connected;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.ui.AbstractSwing#addMenu(javax.swing.JMenu)
	 */
	@Override
	protected JMenu addMenu(JMenu menu) {
		JMenu newMenu = null;
		if (menu.getActionCommand().equals(I18n.getText("gui.menu.edit"))) {
			newMenu = createMenu(I18n.getText("patents.options"), KeyEvent.VK_O);
			newMenu.add(createMenuItem(I18n.getText("patents.look_and_feel"),
					"Look and Feel", KeyEvent.VK_L));
		}
		return newMenu;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.ui.AbstractSwing#addMenuItem(javax.swing.JMenuItem)
	 */
	@Override
	protected JMenuItem addMenuItem(JMenuItem menuItem) {
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.ui.AbstractSwing#addUserComponent(int)
	 */
	@Override
	protected JComponent addUserComponent(int index) {
		switch (index) {
		case 0:
			return getCursorComponent();
		case 1:
			return createEmptyComponent();
		case 2:
			return createEmptyComponent();
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.ui.AbstractSwing#addButton(javax.swing.JButton)
	 */
	@Override
	protected JButton addButton(JButton button) {
		JButton newButton = null;
		if (button.getActionCommand().equals("Paste")) {
			newButton = createButton(Emulator.class, "duke.gif",
					"Look and Feel", I18n.getText("patents.tip"));
		}
		return newButton;
	}

	/**
	 * Implements the Look and Feel dialog box.
	 */
	private void changeLookAndFeel() {
		myIsCancelled = false;
		final JDialog dialog = new JDialog(this,
				I18n.getText("patents.look_and_feel"), true);
		dialog.getContentPane().setLayout(new BorderLayout());
		dialog.setResizable(false);
		KeyAdapter finished = new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					dialog.setVisible(false);
				}
			}
		};
		JButton ok = new JButton(I18n.getText("gui.dialog.ok"));
		ok.setFont(CONTROL_FONT);
		ok.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				dialog.setVisible(false);
			}
		});
		ok.addKeyListener(finished);

		JButton cancel = new JButton(I18n.getText("gui.dialog.cancel"));
		cancel.setFont(CONTROL_FONT);
		cancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent event) {
				dialog.setVisible(false);
				myIsCancelled = true;
			}
		});

		JPanel panel = new JPanel();
		panel.add(Box.createHorizontalGlue());
		panel.add(ok);
		panel.add(cancel);
		panel.add(Box.createHorizontalGlue());
		dialog.getContentPane().add(panel, BorderLayout.SOUTH);

		panel = new JPanel();
		final JComboBox combo = new JComboBox();
		combo.setFont(CONTROL_FONT);
		for (Object key : myLookAndFeelMap.keySet()) {
			try {
				Class.forName((String) myLookAndFeelMap.get(key));
				combo.addItem(key);
			} catch (ClassNotFoundException e) {
			}
		}
		combo.setSelectedIndex(0);
		panel.add(combo);
		dialog.getContentPane().add(panel, BorderLayout.CENTER);

		ok.grabFocus();

		dialog.pack();
		dialog.setLocationRelativeTo(this);
		dialog.setVisible(true);

		if (myIsCancelled) {
			return;
		}

		try {
			UIManager.setLookAndFeel((String) myLookAndFeelMap.get(combo
					.getSelectedItem()));
			SwingUtilities.updateComponentTreeUI(this);
			pack();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.jagacy.ui.AbstractSwing#processAction(java.awt.event.ActionEvent)
	 */
	@Override
	protected boolean processAction(ActionEvent event) {
		boolean processed = false;
		String command = event.getActionCommand();
		if (command.startsWith("About ")) {
			JOptionPane.showMessageDialog(this, getProductName() + "\n"
					+ "Copyright " + COPYRIGHT_SIGN_SYMBOL
					+ " My Software.\nAll Rights Reserved.\n"
					+ "(Portions copyright " + COPYRIGHT_SIGN_SYMBOL
					+ " Jagacy Software)", "About " + getProductName(),
					JOptionPane.INFORMATION_MESSAGE, ICON);
			processed = true;
		} else if (command.equals("Look and Feel")) {
			changeLookAndFeel();
			processed = true;
		}
		return processed;
	}

}
