package esi.automation.recorder;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jagacy.Key;
import com.jagacy.Session3270;
import com.jagacy.ui.UserInterface;
import com.jagacy.util.JagacyException;

import esi.automation.home.utils.AutomationUtils;
public  class JsonRecorder extends Session3270 {
	
	static Logger log = Logger.getLogger(JsonRecorder.class);
	private UserInterface myUi;
	private JsonList jsonList;
	/**
	 * Creates a Patent session.
	 * 
	 * @param name
	 *            The session name (also the name of the .properties file).
	 * @param ui
	 *            The UI used to display the session.
	 * @throws JagacyException
	 *             If an error occurs.
	 */
	public JsonRecorder(String name, UserInterface ui,JsonList jsonList) throws JagacyException {
		super(name, "mcfl1g05.medco.com", "IBM-3278-2");
		this.jsonList=jsonList;
		myUi = ui;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.Session3270#createUi()
	 */
	@Override
	protected UserInterface createUi() throws JagacyException {
		return myUi;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.AbstractSession#logon()
	 */
	@Override
	protected boolean logon() throws JagacyException {
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jagacy.AbstractSession#logoff()
	 */
	@Override
	protected void logoff() throws JagacyException {
		if (logon()) {
			   try {
				stepsToJson(jsonList.getListInputObjects());
			} catch (JsonGenerationException e) {
				log.error("JsonGeneration error"+e.getMessage());
			} catch (JsonMappingException e) {
				log.error("JsonMapping error"+e.getMessage());
			} catch (IOException e) {
				log.error(" error"+e.getMessage());
			} catch (Exception e) {
				log.error(" error"+e.getMessage());
			}
			return;
		}

		writeKey(Key.PF3);
	}

	
	public void stepsToJson(List<InputObject> objectOne) throws JsonGenerationException,JsonMappingException,IOException,Exception{
		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);
		FileOutputStream outputStreamOne;
		if(objectOne!=null){
		String fileName = new SimpleDateFormat("yyyyMMddHHmm'.json'").format(new Date());
			File file = new File(fileName);
			if (!file.exists()) {
				file.createNewFile();
			}
			outputStreamOne = new FileOutputStream(file, true);

			JsonNode nodeOne = mapper.convertValue(objectOne, JsonNode.class);
			mapper.writeValue(outputStreamOne, nodeOne);

			outputStreamOne.close();

			String jsonInStringOne = mapper.writerWithDefaultPrettyPrinter()
					.writeValueAsString(objectOne);
			AutomationUtils.commitFileToGit(new File(file.getAbsoluteFile().getParentFile().getAbsolutePath()), false);
			log.info(jsonInStringOne);
		}
	}
}

