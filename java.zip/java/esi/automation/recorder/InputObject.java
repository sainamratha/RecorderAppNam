package esi.automation.recorder;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


public class InputObject {
	
	private Map<String,Object> input = new HashMap<String, Object>();
	
	public Map<String, Object> getinput() {
	        return Collections.unmodifiableMap(input);
	}
	
	public void addinput(String key, Object value){
		input.put(key, value);
	}
}
