package esi.automation.hub.framework;

public abstract class TestStep {
	
	public abstract void executeTestStep();

}
