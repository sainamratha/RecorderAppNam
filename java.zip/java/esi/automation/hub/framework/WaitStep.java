package esi.automation.hub.framework;


public class WaitStep extends TestStep{

	@Override
	public void executeTestStep() {
		// TODO Auto-generated method stub
		
	}

	
}
