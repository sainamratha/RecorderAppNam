package esi.automation.hub.framework;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.f3270.FieldIdentifier;
import net.sf.f3270.Terminal;

import org.apache.log4j.Logger;
import org.h3270.host.Field;
import org.h3270.host.InputField;
import org.h3270.host.S3270.TerminalMode;
import org.h3270.host.S3270.TerminalType;
import org.springframework.util.StringUtils;

import esi.automation.home.model.EachStepResponseResult;
import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.MainframeTestStep;
import esi.automation.home.model.Step;
import esi.automation.home.parser.Keywords;
import esi.automation.home.utils.AutomationUtils;
import esi.automation.home.utils.GrabScreenShots;

public class F3270Executer implements TestExecutor{

	static Logger log = Logger.getLogger(F3270Executer.class);
	List<Step> testSteps = null;
	MainframeTestCase testCase = null;
	List<EachStepResponseResult> responseResultList = new ArrayList<EachStepResponseResult>();
	Map<String,String> sessionData = new HashMap<String, String>();
	public static F3270Executer getInstance(MainframeTestCase testCase) throws Exception {

        if (null == testCase)
            throw new Exception("stepList object is null");
        
        F3270Executer executor = new F3270Executer(testCase);
        executor.testSteps = testCase.getTestSteps();
        return executor;
    }
	
	private F3270Executer(MainframeTestCase testCase) throws IOException {
		this.testCase = testCase;
		connect(testCase.getHost(),testCase.getPort(),Mode.DIRECT);	
    }

	
	public enum Mode {
        DIRECT, RECORD, REPLAY;
    }

    protected Terminal terminal;

    protected final void connect(String host, String port, Mode mode) {
        String dataFilePath = this.getClass().getPackage().getName().replace('.', '/') + "/"
                + this.getClass().getSimpleName() + ".txt";

        String hostname = null;
        int connectionPort = 23;
        if (mode == Mode.DIRECT) {
            hostname = host;
            connectionPort = Integer.parseInt(port);
        }
        
        String os = System.getProperty("os.name");
        String s3270Path = "s3270";
        if (os.toLowerCase().contains("windows")) {
            s3270Path = "lib/cygwin/s3270";
            String path = this.getClass().getClassLoader().getResource("").getPath();
            if(path.indexOf("WEB-INF")>0){
            	s3270Path = path.substring(1,path.indexOf("/",path.indexOf("WEB-INF")))+"/lib/cygwin/s3270";
            	log.info("Path: "+s3270Path);
            }
        }
        terminal = new Terminal(s3270Path, hostname, connectionPort, TerminalType.TYPE_3279, TerminalMode.MODE_80_24, true);
        terminal.connect();
    }

    protected void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    
	@Override
	public TestResult execute() throws Exception{
		
		TestResult result = new TestResult();
		int index = 0;
		String validationFaliure = null;
		String readField = null;
		
		for (Step step : this.testSteps) {
			String testResult = "success";
			if (step instanceof MainframeTestStep){
				MainframeTestStep testStep = (MainframeTestStep) step;
				index++;
	            log.info("Processing - Step - " + index + " - " + testStep.getStepName() + " Value - "
	                    + testStep.getValue() + " * Label - " + testStep.getLabel() + " * LabelPosition - "
	                    + testStep.getLabelPosition() + " * Co-ordinates - " + testStep.getRow() + "/"
	                    + testStep.getColumn() + " * Key name - " + testStep.getKeyname() + " * Wait time - "
	                    + testStep.getTimeInMillis() + " * Field Number - " + testStep.getField_no());
	
	            if (testStep.getValue() != null && testStep.getValue().startsWith("$")){
	            	testStep.setValue(testStep.getValue());
	            }
	            switch (testStep.getType()) 
	            {
	            case Keywords.TEST_STEP_WAIT_FOR_CORDINATE:
					sleep(testStep.getTimeInMillis().intValue());
					break;

				case Keywords.TEST_STEP_WAIT_FOR_TIME:
					sleep(testStep.getTimeInMillis().intValue());
					break;

				case Keywords.TEST_STEP_WRITE_AT_CORDINATE:
					InputField input = terminal.getField(testStep.getColumn().intValue(), testStep.getRow().intValue());
					if(input != null){
						terminal.write(input.getScreen().getFields().indexOf(input), testStep.getValue(), true);
					}
					else{
						validationFaliure = "Could not perform write operation for the cordinate "
								+ testStep.getRow() + " and " + testStep.getColumn()
								+ ", Step No/Name "
								+ index
								+ " - " + testStep.getStepName();
						throw new Exception(validationFaliure);
					}
					break;

				case Keywords.TEST_STEP_WRITE_AT_LABEL:
					String searchLabel = testStep.getLabel();
					Field field = null;
					int i = 0;
					if(searchLabel.contains("%")){
						searchLabel = searchLabel.replaceAll("%", "");
					}
					
					field = terminal.getField(new FieldIdentifier(searchLabel,
						0));
					
					if (field != null) {
						InputField inputField = null;
						if(StringUtils.hasText(testStep.getLabelPosition()) && testStep.getLabelPosition().equalsIgnoreCase("before")){
							inputField = terminal.getField(field.getScreen().getFields().indexOf(field) - 1,
									"I", true);
						}
						else{
							 inputField = terminal.getField(field.getScreen().getFields().indexOf(field) + 1,
								"I", true);
						}
						while (inputField == null) {
							field = terminal.getField(new FieldIdentifier(
									searchLabel, 0, ++i));
							if(StringUtils.hasText(testStep.getLabelPosition()) && testStep.getLabelPosition().equalsIgnoreCase("before")){
								inputField = terminal.getField(field.getScreen().getFields().indexOf(field) - 1,
										"I", true);
							}
							else{
								inputField = terminal.getField(field.getScreen()
									.getFields().indexOf(field) + 1, "I", true);
							}
						}
						if(testStep.getValue().contains("$")){
							testStep.setValue(sessionData.get(testStep.getValue()));
						}
						if (inputField != null && inputField.isWritable()) {
							if(StringUtils.hasText(testStep.getLabelPosition()) && testStep.getLabelPosition().equalsIgnoreCase("before")){
								terminal.write(field.getScreen().getFields()
										.indexOf(field) - 1, testStep.getValue(),
										true);
							}
							else{
								terminal.write(field.getScreen().getFields()
									.indexOf(field) + 1, testStep.getValue(),
									true);
							}
							if (testStep.getValue().length() > (inputField
									.getEndX() - inputField.getStartX()) + 1) {
								String remainingValue = testStep
										.getValue()
										.substring(
												(inputField.getEndX() - inputField
														.getStartX()) + 1,
												testStep.getValue().length());
								inputField = terminal.getField(
										field.getScreen().getFields()
												.indexOf(field) + 2, "I", true);
								if (inputField != null
										&& inputField.isWritable()) {
									terminal.write(field.getScreen()
											.getFields().indexOf(field) + 2,
											remainingValue, true);
								}
							}
						} else {
							validationFaliure = "Could not perform write operation for the label "
									+ searchLabel
									+ ", Step No/Name "
									+ index
									+ " - " + testStep.getStepName();
							throw new Exception(validationFaliure);
						}
					}
					break;

				case Keywords.TEST_STEP_WRITE_AT_FIELD:
					terminal.write(new FieldIdentifier(testStep.getLabel(), 1),
							testStep.getValue());
					break;

				case Keywords.TEST_STEP_SEND_KEY_NAME:

					if (testStep.getKeyname().equalsIgnoreCase("ENTER")) {
						terminal.enter();
					}
					else if (testStep.getKeyname().equalsIgnoreCase("PF5")) {
						terminal.pf(5);
					}else if (testStep.getKeyname().equalsIgnoreCase("PF3")) {
						terminal.pf(3);
                    } else if (testStep.getKeyname().equalsIgnoreCase("PF8")) {
                    	terminal.pf(8);
                    } else if (testStep.getKeyname().equalsIgnoreCase("PF9")) {
                    	terminal.pf(9);
                    }
					break;
				case Keywords.TEST_STEP_READ_AT_LABEL:
					terminal.read(new FieldIdentifier(testStep.getLabel(), 0));
					break;

				case Keywords.TEST_STEP_READ_AT_FIELDNUMBER:
					terminal.read(new FieldIdentifier(testStep.getLabel(), 0));
					break;

				case Keywords.TEST_STEP_READ_AT_CORDINATE:
					String value = terminal.read(testStep.getRow().intValue());
					value = value.replaceAll("\0", " ");
					String sessionKeyName = "$" + testStep.getValue();
					String sessionValue = value.substring(testStep.getColumn().intValue(), value.indexOf(" ",	testStep.getColumn().intValue()));
					sessionData.put(sessionKeyName, sessionValue);					
					break;

				case Keywords.TEST_STEP_ASSERT_AT_CORDINATE:
					boolean negativeAssert = testStep.getOperator() != null
							&& testStep.getOperator().equals("not_equal");
					readField = terminal.read(new FieldIdentifier(testStep
							.getValue(), 0));
					if (!readField.isEmpty() && !negativeAssert) {
						log.info("Assert - Step - " + index + " - "
								+ testStep.getStepName() + " id: "
								+ testStep.getStepId() + " Assert Value: "
								+ testStep.getValue()
								+ " Actual Value  Found: " + readField
								+ " assert passed");
					} else if (readField.isEmpty() && negativeAssert) {
						log.info("Assert - Step - " + index + " - "
								+ testStep.getStepName() + " id: "
								+ testStep.getStepId() + " Assert Value: "
								+ testStep.getValue()
								+ " Actual Value  Found: " + readField
								+ " assert passed");
					} else {
						log.info("Assert - Step - " + index + " - "
								+ testStep.getStepName() + " id: "
								+ testStep.getStepId() + " Assert Value: "
								+ testStep.getValue()
								+ " Actual Value  Found: " + readField
								+ " assert failed");
						testResult = "fail";
					}

					break;
				case Keywords.TEST_STEP_ASSERT_AT_LABEL:
					negativeAssert = testStep.getOperator() != null
							&& testStep.getOperator().equals("not_equal");
					readField = terminal.read(new FieldIdentifier(testStep
							.getLabel(), 0));
					if (!readField.isEmpty() && !negativeAssert) {
						log.info("Assert - Step - " + index + " - "
								+ testStep.getStepName() + " id: "
								+ testStep.getStepId() + " Assert Value: "
								+ testStep.getValue()
								+ " Actual Value  Found: " + readField
								+ " assert passed");
					} else if (readField.isEmpty() && negativeAssert) {
						log.info("Assert - Step - " + index + " - "
								+ testStep.getStepName() + " id: "
								+ testStep.getStepId() + " Assert Value: "
								+ testStep.getValue()
								+ " Actual Value  Found: " + readField
								+ " assert passed");
					} else {
						log.info("Assert - Step - " + index + " - "
								+ testStep.getStepName() + " id: "
								+ testStep.getStepId() + " Assert Value: "
								+ testStep.getValue()
								+ " Actual Value  Found: " + readField
								+ " assert failed");
						testResult = "fail";
					}
					break;
				case Keywords.TEST_STEP_ASSERT_AT_FIELDNUMBER:

					break;
				default:
					validationFaliure = "Parameter Passed inside JSON is Incorrect, Step No/Name "
							+ index + " - " + testStep.getStepName();
					throw new IllegalArgumentException(validationFaliure);
				}
				String urlToScreenShot = null;

				if (testCase != null
						&& testCase.getScreenshot().equalsIgnoreCase("on")) {
					try {
						urlToScreenShot = GrabScreenShots.setScreenImage(index);
					} catch (Exception e) {
						addResponseResult(Integer.toString(index), "fail",
								urlToScreenShot, e.getLocalizedMessage());
						e.printStackTrace();
					}
				}
    
	            }
	            String urlToScreenShot = null;
	
	            if (testCase != null && testCase.getScreenshot().equalsIgnoreCase("on")) {
	                try {
	                    urlToScreenShot = GrabScreenShots.setScreenImage(index);
	                } catch (Exception e) {
	                    addResponseResult(Integer.toString(index), "fail", urlToScreenShot, e.getLocalizedMessage());
	                    e.printStackTrace();
	                }
	            }
	            addResponseResult(Integer.toString(index), testResult, urlToScreenShot, null);
		}
		return result;
	}
	
	private void addResponseResult(String runID, String results, String urlToScreenShot, String validationFaliure) {

        EachStepResponseResult responseResult = new EachStepResponseResult();
        responseResult.setExecutionTime(AutomationUtils.getCurrentDateTimeHrsMillSec());
        responseResult.setResults(results);
        responseResult.setRunID(runID);
        if (urlToScreenShot != null) {
            responseResult.setUrlToScreenShot(urlToScreenShot);
        }
        if (validationFaliure != null) {
            responseResult.setValidationFaliure(validationFaliure);
        }

        responseResultList.add(responseResult);

    }
	
}
