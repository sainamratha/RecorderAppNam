package esi.automation.hub.framework;


public interface TestExecutor {
		public abstract TestResult execute() throws Exception;
}
