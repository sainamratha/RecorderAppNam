package esi.automation.hub.framework;

import java.io.File;
import java.io.FileReader;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.util.StringUtils;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.Step;

public class TestClient {
	
	static Logger log = Logger.getLogger(TestClient.class);
	
	public TestResult runTest(String jsonString){
		TestParser parser = new TestParser();
		JSONObject jsonObject = null;
		MainframeTestCase mainframeTestCase = null;
		
		if(StringUtils.isEmpty(jsonString)){
			return null;
		}
		
		try {
			//Validate JSON			
			jsonObject = parser.convertStringToJSONObject(jsonString);
			
			//Parse Json and create mainframe test case Object
			mainframeTestCase = parser.parse(jsonObject);
		}
		catch(Exception ex){
			log.error(ex.getMessage());
		}
		return runTest(mainframeTestCase);
		
	}
	
	public TestResult runTest(File JsonFile){
		MainframeTestCase mainframeTestCase = null;
		TestParser parser = new TestParser();
		try {
			//Parse File
			mainframeTestCase = parser.parse(JsonFile);
		}catch(Exception ex){
			log.error(ex.getMessage());
		}
		return runTest(mainframeTestCase);
	}
	
	private TestResult runTest(MainframeTestCase mainframeTestCase){
		TestExecutor executor = null;
		TestResult result = null;
		try {
			//Execute the test case and capture result
			if(StringUtils.hasText(mainframeTestCase.getDriver()) && mainframeTestCase.getDriver().equalsIgnoreCase("f3270")){
				executor = F3270Executer.getInstance(mainframeTestCase);
			}
			else{
				executor = JagacyExecutor.getInstance(mainframeTestCase);
			}
            result = executor.execute();
		}catch(Exception ex){
			log.error(ex.getMessage());
		}
		return result;
	}

}
