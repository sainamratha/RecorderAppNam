/**
 * 
 */
package esi.automation.hub.tdm.client;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * @author eh2966
 *
 */
public class TDMClient {

	static Logger log = Logger.getLogger(TDMClient.class);

	/**
	 * Returns output from TDM service as a composite JSONObject
	 * 
	 * @param url
	 *            Consolidated URL from Test Case JSON configuration and TDM
	 *            test step payload's url
	 * @param inputData
	 *            JSON request payload to be sent as a 'POST' request and which
	 *            is configured in the TDM step of the JSON test case
	 * @return JSON object as returned by TDM service(currently first element of
	 *         an array)
	 */
	public JSONArray getTestData(String url, JSONObject inputData) {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost post = new HttpPost(url);
		post.addHeader("accept", "application/json");
		JSONParser parser = new JSONParser();
		JSONArray responseBody = null;
		log.debug("TDMClient -> getTestData -> HTTP client to retrieve test data from TDM as JSON");
		try {
			StringEntity requestEntity = new StringEntity(
					inputData.toJSONString(), ContentType.APPLICATION_JSON);
			post.setEntity(requestEntity);

			// Create a custom response handler
			ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

				@Override
				public String handleResponse(final HttpResponse response)
						throws ClientProtocolException, IOException {
					log.debug("TDMClient -> getTestData -> Response Handler for TDM service response");
					int status = response.getStatusLine().getStatusCode();
					if (status >= 200 && status < 300) {
						HttpEntity entity = response.getEntity();
						return entity != null ? EntityUtils.toString(entity)
								: null;
					} else {
						ClientProtocolException excep = new ClientProtocolException(
								"Unexpected response status: " + status);
						log.fatal(
								"TDMClient -> getTestData -> ResponseHandler -> handleResponse -> TDM call failed",
								excep);
						throw excep;
					}
				}
			};
			String serviceOutput = httpclient.execute(post, responseHandler);
			responseBody = (JSONArray) parser.parse(serviceOutput);

			System.out.println("----------------------------------------");
			log.debug("TDMClient -> getTestData -> \n" + responseBody);

		} catch (ParseException e) {
			log.fatal(
					"TDMClient -> getTestData -> Exception while parsing TDM response",
					e);
		} catch (ClientProtocolException e) {
			log.fatal("TDMClient -> getTestData -> TDM interface failure ", e);
		} catch (IOException e) {
			log.fatal("TDMClient -> getTestData -> TDM interface failure ", e);
		}
		return responseBody;
	}

}
