/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.service;

import esi.automation.home.model.ResponseResult;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public interface ProcessTestCaseService {

	ResponseResult readAndExecuteSteps(String fileName, String timeOut) throws Exception;

}
