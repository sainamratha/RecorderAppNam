/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.service;

import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jagacy.util.JagacyException;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;
import esi.automation.hub.framework.F3270Executer;
import esi.automation.hub.framework.TestResult;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
@Service
public class ProcessTestCaseServiceImpl implements ProcessTestCaseService {

    /*
     * (non-Javadoc)
     * 
     * @see
     * esi.automation.home.service.ProcessTestCase#readAndExecuteSteps(java.
     * lang.String)
     */
    static Logger log = Logger.getLogger(ProcessTestCaseServiceImpl.class);

	@Autowired
	ApplicationContext context;
	static int max = 0;

	@Override
	public ResponseResult readAndExecuteSteps(String jsonTestSteps,String timeOut)
			throws JagacyException, IOException, Exception {
		ResponseResult responseResult = null;
		Executer executor = null;
		try {
			executor = (Executer) context.getBean("executer");
		} catch (Exception e) {
			throw new Exception("No more connections available, retry later");
		}
		Properties appProperties = (Properties) context
				.getBean("requiredProperties");
		if (executor != null && executor.getUserId() == null
				&& executor.getPwd() == null) {
			if (max == 0) {
				max = Integer.parseInt(appProperties
						.getProperty("genericIds.count"));
			}
			executor.setUserId(appProperties.getProperty("genericId." + max
					+ ".userId"));
			executor.setPwd(appProperties.getProperty("genericId." + max
					+ ".pwd"));
			max--;
		}
		System.out.println("max: " + max);
		F3270Executer f3270Executer = null;
		try {

			JSONParser parser = new JSONParser();
			JSONObject jsonObject = (JSONObject) parser.parse(jsonTestSteps);
			Parser testautomationParser = new Parser();
			MainframeTestCase mainframeTestCase = testautomationParser
					.parse(jsonObject);
			if (StringUtils.hasText(mainframeTestCase.getDriver())
					&& mainframeTestCase.getDriver().equalsIgnoreCase("f3270")) {
				f3270Executer = F3270Executer.getInstance(mainframeTestCase);
				TestResult testResult = f3270Executer.execute();
				responseResult = new ResponseResult();
				responseResult.setResponseResultList(testResult
						.getResponseResultList());
				responseResult.setSessionData(testResult.getSessionData());
			} else {
				if (executor != null) {
					executor.getInstance(mainframeTestCase);
					responseResult = executor.execute(timeOut);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responseResult;
	}
}
