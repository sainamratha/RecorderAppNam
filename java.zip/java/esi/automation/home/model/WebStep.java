package esi.automation.home.model;

public class WebStep extends Step {

	private String webStepName = "";
	private String webUrl;
	private String browser;
	private String selectBy;
	private String elementID;
	private String value;
	private String milisec;
	// private String switchToFrame;
	// private String alertv;
	private String action;

	private String window;
	private String Close;
	private String frame;

	private Long row;
	private Long column;
	private String alert;

	public String getAlert() {
		return alert;
	}

	public void setAlert(String alert) {
		this.alert = alert;
	}

	public Long getRow() {

		return row;
	}

	public void setRow(Long row) {

		this.row = row;
	}

	public Long getColumn() {

		return column;
	}

	public void setColumn(Long column) {

		this.column = column;
	}

	public String getWindow() {

		return window;
	}

	public void setWindow(String window) {

		this.window = window;
	}

	public String getAction() {

		return action;
	}

	public void setAction(String action) {

		this.action = action;
	}

	public String getFrame() {

		return frame;
	}

	public void setFrame(String frame) {

		this.frame = frame;
	}

	public String getClose() {

		return Close;
	}

	public void setClose(String close) {

		Close = close;
	}

	/*
	 * public String getAlertv() { return alertv; } public void setAlertv(String
	 * alertv) { this.alertv = alertv; }
	 */

	/*
	 * public String getSwitchToWin() { return switchToWin; } public void
	 * setSwitchToWin(String switchToWin) { this.switchToWin = switchToWin; }
	 */
	public String getMilisec() {

		return milisec;
	}

	public void setMilisec(String milisec) {

		this.milisec = milisec;
	}

	public String getElementID() {

		return elementID;
	}

	public void setElementID(String elementID) {

		this.elementID = elementID;
	}

	/*
	 * public String getSwitchToFrame() { return switchToFrame; } public void
	 * setSwitchToFrame(String switchToFrame) { this.switchToFrame =
	 * switchToFrame; }
	 */
	public String getSelectBy() {

		return selectBy;
	}

	public void setSelectBy(String selectBy) {

		this.selectBy = selectBy;
	}

	public String getElementName() {

		return elementID;
	}

	public void setElementName(String elementName) {

		this.elementID = elementName;
	}

	public String getValue() {

		return value;
	}

	public void setValue(String value) {

		this.value = value;
	}

	private boolean isScreenShotRequired;

	public String getWebStepName() {

		return webStepName;
	}

	public void setWebStepName(String webStepName) {

		this.webStepName = webStepName;
	}

	public String getWebUrl() {

		return webUrl;
	}

	public void setWebUrl(String webUrl) {

		this.webUrl = webUrl;
	}

	public String getBrowser() {

		return browser;
	}

	public void setBrowser(String browser) {

		this.browser = browser;
	}

	public boolean isScreenShotRequired() {

		return isScreenShotRequired;
	}

	public void setScreenShotRequired(boolean isScreenShotRequired) {

		this.isScreenShotRequired = isScreenShotRequired;
	}

}
