/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.model;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class EachStepResponseResult {

    String runID;
    String executionTime;
    String results;
    String urlToScreenShot;
    String validationFaliure;

    public String getRunID() {

        return this.runID;
    }

    public void setRunID(String runID) {

        this.runID = runID;
    }

    public String getExecutionTime() {

        return this.executionTime;
    }

    public void setExecutionTime(String executionTime) {

        this.executionTime = executionTime;
    }

    public String getResults() {

        return this.results;
    }

    public void setResults(String results) {

        this.results = results;
    }

    public String getValidationFaliure() {

        return this.validationFaliure;
    }

    public void setValidationFaliure(String validationFaliure) {

        this.validationFaliure = validationFaliure;
    }

    public String getUrlToScreenShot() {

        return this.urlToScreenShot;
    }

    public void setUrlToScreenShot(String urlToScreenShot) {

        this.urlToScreenShot = urlToScreenShot;
    }

}
