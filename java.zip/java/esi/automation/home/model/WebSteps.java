package esi.automation.home.model;

import java.util.ArrayList;
import java.util.List;

public class WebSteps extends Step {

    private List<WebStep> webSteps = new ArrayList<WebStep>();

    public List<WebStep> getWebSteps() {

        return webSteps;
    }

    public void setWebSteps(List<WebStep> webSteps) {

        this.webSteps = webSteps;
    }

}
