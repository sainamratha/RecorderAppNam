/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.model;

import java.util.List;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class MainframeTestCase {

    private String name;
    private String curator;
    private String screenshot;
    private String host;
    private String port;
    private String driver;
    private String browser;
    private String application;
    private String pillar;
    private String environment;
    private String tdmUrl;
    

    /**
     * 
     */
    public MainframeTestCase() {

        super();
        // Auto-generated constructor stub
    }

    /**
     * @param name
     * @param curator
     * @param screenshot
     * @param host
     * @param port
     * @param driver
     * @param browser
     * @param application
     * @param pillar
     * @param environment
     * @param tdmUrl
     */
    public MainframeTestCase(String name, String curator, String screenshot, String host, String port, String driver,
            String browser, String application, String pillar, String environment, String tdmUrl) {

        super();
        this.name = name;
        this.curator = curator;
        this.screenshot = screenshot;
        this.host = host;
        this.port = port;
        this.driver = driver;
        this.browser = browser;
        this.application = application;
        this.pillar = pillar;
        this.environment = environment;
        this.tdmUrl = tdmUrl;
    }

    public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getPillar() {
		return pillar;
	}

	public void setPillar(String pillar) {
		this.pillar = pillar;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	private List<Step> testSteps;

    public String getName() {

        return this.name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getCurator() {

        return this.curator;
    }

    public void setCurator(String curator) {

        this.curator = curator;
    }

    public String getScreenshot() {

        return this.screenshot;
    }

    public void setScreenshot(String screenshot) {

        this.screenshot = screenshot;
    }

    public String getHost() {

        return this.host;
    }

    public void setHost(String host) {

        this.host = host;
    }

    public String getPort() {

        return this.port;
    }

    public void setPort(String port) {

        this.port = port;
    }

    public List<Step> getTestSteps() {

        return this.testSteps;
    }

    public void setTestSteps(List<Step> testSteps) {

        this.testSteps = testSteps;
    }

    /**
     * @return the driver
     */
    public String getDriver() {

        return driver;
    }

    /**
     * @param driver
     *            the driver to set
     */
    public void setDriver(String driver) {

        this.driver = driver;
    }

    /**
     * @return the browser
     */
    public String getBrowser() {

        return browser;
    }

    /**
     * @param browser
     *            the browser to set
     */
    public void setBrowser(String browser) {

        this.browser = browser;
    }
    
    /**
	 * @return the tdmUrl
	 */
	public String getTdmUrl() {
		return tdmUrl;
	}

	/**
	 * @param tdmUrl the tdmUrl to set
	 */
	public void setTdmUrl(String tdmUrl) {
		this.tdmUrl = tdmUrl;
	}

}
