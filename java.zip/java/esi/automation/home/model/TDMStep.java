/**
 * 
 */
package esi.automation.home.model;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * @author EH2966
 *
 */
public class TDMStep extends Step {
	private String name;
	private String serviceId;	
	private long count;
	private JSONObject tdmFilterPayload;
	private JSONArray tdmResponse;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the serviceId
	 */
	public String getServiceId() {
		return serviceId;
	}
	/**
	 * @param serviceId the serviceId to set
	 */
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	/**
	 * @return the count
	 */
	public long getCount() {
		return count;
	}
	/**
	 * @param count the count to set
	 */
	public void setCount(long count) {
		this.count = count;
	}
	/**
	 * @return the tdmFilterPayload
	 */
	public JSONObject getTdmFilterPayload() {
		return tdmFilterPayload;
	}
	/**
	 * @param tdmFilterPayload the tdmFilterPayload to set
	 */
	public void setTdmFilterPayload(JSONObject tdmFilterPayload) {
		this.tdmFilterPayload = tdmFilterPayload;
	}
	/**
	 * @return the tdmResponse
	 */
	public JSONArray getTdmResponse() {
		return tdmResponse;
	}
	/**
	 * @param tdmResponse the tdmResponse to set
	 */
	public void setTdmResponse(JSONArray tdmResponse) {
		this.tdmResponse = tdmResponse;
	}
	
	
	
}
