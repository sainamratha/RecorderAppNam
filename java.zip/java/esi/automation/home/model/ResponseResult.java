/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class ResponseResult {

    List<EachStepResponseResult> responseResultList = new ArrayList<EachStepResponseResult>();
    HashMap<String, String> sessionData = new HashMap<String, String>();

    public List<EachStepResponseResult> getResponseResultList() {

        return this.responseResultList;
    }

    public void setResponseResultList(List<EachStepResponseResult> responseResultList) {

        this.responseResultList = responseResultList;
    }

    public HashMap<String, String> getSessionData() {

        return this.sessionData;
    }

    public void setSessionData(HashMap<String, String> sessionData) {

        this.sessionData = sessionData;
    }

}
