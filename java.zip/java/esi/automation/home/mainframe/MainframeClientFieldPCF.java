package esi.automation.home.mainframe;

import java.io.IOException;
import java.util.Enumeration;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.jagacy.Field;
import com.jagacy.Key;
import com.jagacy.Session3270;
import com.jagacy.util.JagacyException;
import com.jagacy.util.JagacyProperties;

public class MainframeClientFieldPCF extends Session3270 {

    static Logger log = Logger.getLogger(MainframeClientFieldPCF.class);

    private JagacyProperties props;
    ResourceBundle configuration = null;
    String userid = "ec4848";
    String password = "Sonu2099";

    public MainframeClientFieldPCF() throws JagacyException, IOException {

        super("example - MainframeClient");

        props = getProperties();
        loadProps();
        Enumeration e = configuration.getKeys();
        while (e.hasMoreElements()) {
            String key = (String) e.nextElement();
            String value = configuration.getString(key);
            props.set(key, value);
        }

    }

    @Override
    protected boolean logon() throws JagacyException {

        log.info("********** Begin  -- Processing Mainframe Data ********** ");

        log.info("...Execution Started...");
        waitForPosition("logon.wait", "logon.timeout.seconds");
        log.info("Connected to mfs");

        writePosition("logon.entry", "b");
        writeKey(Key.ENTER);
        waitForPosition("main.wait", "main.timeout.seconds");

        writeAfterLabel("Userid", userid);
        writeAfterLabel("Password", password);
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        log.info("Sign in process has completed succesfully");

        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        writeKey(Key.ENTER);
        waitForPosition("region.entry", "main.timeout.seconds");
        readScreenData();
        readFieldData();

        log.info("....Signed off....");
        log.info("....Testcase flow execution has completed....");

        log.info("********** End    -- Processing Mainframe Data ********** ");

        return true;
    }

    private void readScreenData() throws JagacyException {

        String[] readScreenData = readScreen();
        System.out.println(" *********** Begin Printing Screen Data ************** ");
        int count = 0;
        for (String eachfield : readScreenData) {

            System.out.println("Row Number : " + count + " : " + eachfield.toString());
            count += 1;
        }
        System.out.println(" *********** End Printing Screen Data ************** ");

    }

    private void readFieldData() throws JagacyException {

        Field[] allFields = readFields();
        System.out.println(" *********** Begin Printing Field Data ************** ");
        System.out.println("Total fields count - " + allFields.length);
        for (Field eachfield : allFields) {
            System.out.println("RowNumber : " + eachfield.getRow() + "--\n" + "Column Number : "
                    + eachfield.getColumn() + "\n" + "FieldNumber : " + eachfield.getFieldNumber() + "\n"
                    + "Field Value : " + eachfield.getValue() + "\n" + "Field isModified : " + eachfield.isModified()
                    + "\n" + "Field isNumeric : " + eachfield.isNumeric() + "\n" + "Field isProtected : "
                    + eachfield.isProtected() + "\n");
        }
        System.out.println(" *********** End Printing Field Data ************** ");

    }

    public void loadProps() throws IOException {

        configuration = ResourceBundle.getBundle("fixtures/jagacy/properties/jagacyPCF");
    }

}
