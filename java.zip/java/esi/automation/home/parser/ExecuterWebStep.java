/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.parser;

import java.util.HashMap;

import esi.automation.home.model.EachStepResponseResult;
import esi.automation.home.model.WebStep;
import esi.automation.home.utils.AutomationUtils;
import esi.automation.home.utils.GrabScreenShots;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class ExecuterWebStep {

	// web part

	public EachStepResponseResult executeWebStep(int stepNumber,
			String screenShotOnOff, HashMap<String, String> sessionData,
			WebStep webStep) {

		EachStepResponseResult eachStepResponseResult = null;
		String urlToScreenShot = null;

		try {
			processWebStep(webStep, sessionData);

			if (screenShotOnOff.equalsIgnoreCase("on")) {
				urlToScreenShot = GrabScreenShots.setScreenImage(stepNumber);
			}
			eachStepResponseResult = AutomationUtils
					.getSingleStepResponseResult(Integer.toString(stepNumber),
							Keywords.STEP_RESPONSE_RESULT_SUCCESS,
							urlToScreenShot, null);

		} catch (Exception e) {
			eachStepResponseResult = AutomationUtils
					.getSingleStepResponseResult(Integer.toString(stepNumber),
							Keywords.STEP_RESPONSE_RESULT_FAIL,
							urlToScreenShot, e.getLocalizedMessage());
			e.printStackTrace();
		}
		return eachStepResponseResult;
	}

	public void processWebStep(WebStep webStep,
			HashMap<String, String> sessionData) throws Exception {

		switch (webStep.getWebStepName()) {
		case "navigate":
			WebUtility.Launch(webStep.getBrowser(), webStep.getWebUrl());
			break;
		case "input":
			if (webStep.getValue().startsWith("$")) {
				WebUtility.Input(webStep.getSelectBy(),
						webStep.getElementName(),
						sessionData.get(webStep.getValue().toString()), "Yes",
						0, webStep.getFrame(), webStep.getWindow());
			} else {
				WebUtility.Input(webStep.getSelectBy(),
						webStep.getElementName(), webStep.getValue(), "Yes", 0,
						webStep.getFrame(), webStep.getWindow());
			}
			break;
		case "click":
			WebUtility.Click(webStep.getSelectBy(), webStep.getElementName(),
					"Yes", 100, webStep.getWindow());
			break;

		case "select":
			WebUtility.Select(webStep.getSelectBy(), webStep.getElementName(),
					webStep.getValue(), "Yes", 100, webStep.getFrame(),
					webStep.getWindow());
			break;
		case "alert":
			WebUtility.alert(webStep.getAction(), webStep.getValue());
			break;
		case "getValue":
			WebUtility.getValue(webStep.getFrame(), webStep.getSelectBy(),
					webStep.getElementName(), webStep.getValue(), "Yes", 100);
			break;
		case "assert":
			Asserts.doAssert(webStep.getSelectBy(), webStep.getElementName(),
					webStep.getValue(), "Yes", 100, webStep.getAlert());
			break;
		case "browserclose":
			WebUtility.driverClose(webStep.getClose(), webStep.getWindow());
			break;

		}

	}

}
