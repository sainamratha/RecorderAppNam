package esi.automation.home.parser;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.MainframeTestStep;
import esi.automation.home.model.Step;
import esi.automation.home.model.TDMStep;
import esi.automation.home.model.WebStep;
import esi.automation.home.utils.AutomationUtils;

public class Parser {

	private List<Step> testSteps = new ArrayList<Step>();
	private MainframeTestStep testStep = null;
	private MainframeTestCase testCase = null;
	public HashMap<Integer, String> commonSteps = new HashMap<Integer, String>();

	private final String WEB_STEPS[] = { "WAITFORELEMENT", "BROWSERCLOSE",
			"ASSERT", "INPUT", "NAVIGATE", "CLICK", "ALERT", "SELECT",
			"GETVALUE" };

	static Logger log = Logger.getLogger(Parser.class);

	public JSONArray setJsonElementTestCase(JSONObject jsonObject)
			throws Exception {

		JSONObject jsonChildObject = (JSONObject) jsonObject.get("testCase");
		JSONObject jsonChildConfiguration = (JSONObject) jsonChildObject
				.get("configuration");
		JSONArray jsonArrayTestSteps = (JSONArray) jsonChildObject
				.get("testSteps");

		testCase = new MainframeTestCase(AutomationUtils.getJsonElementValue(
				jsonChildObject, "name"), AutomationUtils.getJsonElementValue(
				jsonChildObject, "curator"),
				AutomationUtils.getJsonElementValue(jsonChildConfiguration,
						"screenshots"), AutomationUtils.getJsonElementValue(
						jsonChildConfiguration, "host"),
				AutomationUtils.getJsonElementValue(jsonChildConfiguration,
						"port"), AutomationUtils.getJsonElementValue(
						jsonChildConfiguration, "driver"),
				AutomationUtils.getJsonElementValue(jsonChildConfiguration,
						"browser"), AutomationUtils.getJsonElementValue(
						jsonChildObject, "application"),
				AutomationUtils.getJsonElementValue(jsonChildObject, "pillar"),
				AutomationUtils.getJsonElementValue(jsonChildObject,
						"environment"),
				AutomationUtils.getJsonElementValue(jsonChildConfiguration, "tdmserviceurl"));

		return jsonArrayTestSteps;
	}

	public MainframeTestCase parse(JSONObject jsonObject) throws Exception {

		JSONArray jsonArray = setJsonElementTestCase(jsonObject);
		setJsonElementTestSteps(jsonArray);
		if (commonSteps.size() > 0) {
			resolveCommonReferenceSteps();

		}
		return testCase;
	}

	public MainframeTestCase parse(File jsonFile) throws Exception {

		JSONParser jsonParser = new JSONParser();
		Object obj = jsonParser.parse(new FileReader(jsonFile));
		JSONObject jsonObject = (JSONObject) obj;
		JSONArray jsonArrayTestSteps = setJsonElementTestCase(jsonObject);

		setJsonElementTestSteps(jsonArrayTestSteps);
		if (commonSteps.size() > 0) {
			resolveCommonReferenceSteps();
		}

		return testCase;
	}

	public MainframeTestCase setJsonElementTestSteps(JSONArray jsonArray)
			throws Exception {

		int count = 0;
		for (Object obj : jsonArray) {
			count++;
			JSONObject jsonObj = (JSONObject) obj;
			if (null != jsonObj) {

				for (Object key : jsonObj.keySet()) {
					String jsonTestStepKey = (String) key;

					if (isWebStep(jsonTestStepKey, jsonObj)) {
						WebStep webStep = new WebStep();
						JSONObject webStepJsonObj = (JSONObject) jsonObj
								.get(jsonTestStepKey);
						webStep = getWebStepFromJsonObj(jsonTestStepKey,
								webStepJsonObj);
						testSteps.add(webStep);
					} else if(null != jsonTestStepKey && !jsonTestStepKey.isEmpty() && jsonTestStepKey.equalsIgnoreCase("data")) {
                    	TDMStep tdmStep = new TDMStep();
                        JSONObject tdmStepJsonObj = (JSONObject) jsonObj.get(jsonTestStepKey);
                        tdmStep = getTdmStepFromJsonObj(tdmStepJsonObj);
                        testSteps.add(tdmStep);
                    } else {
						JSONObject testStepObj = (JSONObject) jsonObj
								.get(jsonTestStepKey);
						testStep = createMainframeSteps(jsonTestStepKey,
								testStepObj);

						if (testStep.getStepName().equalsIgnoreCase("$ref")) {
							commonSteps.put(count, testStep.getValue());
						} else if (testStep.getStepName().equalsIgnoreCase(
								"wait")) {
							if (testStep.getRow() != null
									&& testStep.getColumn() != null
									&& testStep.getValue() != null
									&& testStep.getTimeInMillis() != null) {
								testStep.setType(Keywords.TEST_STEP_WAIT_FOR_CORDINATE);
							} else if (testStep.getTimeInMillis() != null
									&& null == testStep.getRow()) {
								testStep.setType(Keywords.TEST_STEP_WAIT_FOR_TIME);
							}
						} else if (testStep.getStepName().equalsIgnoreCase(
								"input")) {
							if (null != testStep.getOffset()
									&& null != testStep.getField_no()
									&& null != testStep.getLength()) {
								testStep.setType(Keywords.TEST_STEP_WRITE_AT_FIELD);
							} else if (null == testStep.getLabel()
									&& null == testStep.getKeyname()) {
								testStep.setType(Keywords.TEST_STEP_WRITE_AT_CORDINATE);
							} else if (null != testStep.getKeyname()) {
								testStep.setType(Keywords.TEST_STEP_SEND_KEY_NAME);
							} else if (null == testStep.getKeyname()
									&& null != testStep.getLabel()
									&& null != testStep.getValue()) {
								if (null == testStep.getLabelPosition())
									throw new Exception(
											"Label position should be defined : "
													+ testStep.getValue());
								testStep.setType(Keywords.TEST_STEP_WRITE_AT_LABEL);
							} else {
								throw new Exception(
										"Error : Configuration has gone wrong with this step - "
												+ testStep.toString());
							}
						} else if (testStep.getStepName().equalsIgnoreCase(
								"readValue")) {
							if (testStep.getField_no() != null
									&& testStep.getValue() != null) {
								testStep.setType(Keywords.TEST_STEP_READ_AT_FIELDNUMBER);

							} else if (null == testStep.getLabel()
									&& null == testStep.getKeyname()) {
								testStep.setType(Keywords.TEST_STEP_READ_AT_CORDINATE);

							} else if (testStep.getLabel() != null
									&& testStep.getLabelPosition() != null
									&& testStep.getValue() != null) {
								testStep.setType(Keywords.TEST_STEP_READ_AT_LABEL);
							} else {
								throw new Exception(
										"Error : Configuration has gone wrong with this step - "
												+ testStep.toString());
							}
						} else if (testStep.getStepName().equalsIgnoreCase(
								"assert")) {
							if (testStep.getField_no() != null
									&& testStep.getValue() != null) {
								testStep.setType(Keywords.TEST_STEP_ASSERT_AT_FIELDNUMBER);
							} else if (testStep.getRow() != null
									&& testStep.getColumn() != null
									&& testStep.getValue() != null) {
								testStep.setType(Keywords.TEST_STEP_ASSERT_AT_CORDINATE);
							} else if (testStep.getLabel() != null
									&& testStep.getLabelPosition() != null
									&& testStep.getValue() != null) {
								testStep.setType(Keywords.TEST_STEP_ASSERT_AT_LABEL);
							} else {
								throw new Exception(
										"Error : Configuration has gone wrong with this step - "
												+ testStep.toString());
							}
						} else if (testStep.getStepName().equalsIgnoreCase(
								"select")) {
							if (testStep.getValue() != null) {
								testStep.setType(Keywords.TEST_STEP_ADD_PRADD);
							} else {
								throw new Exception(
										"Error : Configuration has gone wrong with this step - "
												+ testStep.toString());
							}

						} else if (testStep.getStepName().equalsIgnoreCase(
								"addPRRSL")) {
							if (testStep.getpRRSLValue() != null) {
								testStep.setType(Keywords.TEST_STEP_DEMO);
							} else {
								throw new Exception(
										"Error : Configuration has gone wrong with this step - "
												+ testStep.toString());
							}
						}
						testSteps.add(testStep);
					}
				}
			}
		}

		testCase.setTestSteps(testSteps);
		return testCase;
	}

	private WebStep getWebStepFromJsonObj(String key, JSONObject webStepJsonObj) {

		WebStep webStep = null;
		webStep = new WebStep();
		if (key.equals("navigate")) {
			String url = (String) webStepJsonObj.get("url");
			webStep.setBrowser(testCase.getBrowser());
			webStep.setWebUrl(url);
			webStep.setWebStepName("navigate");

		} else if (key.equals("input")) {
			String frame = (String) webStepJsonObj.get("frame");
			String window = (String) webStepJsonObj.get("window");
			String selectBy = (String) webStepJsonObj.get("selectBy");
			String elementId = (String) webStepJsonObj.get("elementID");
			String inputValue = (String) webStepJsonObj.get("value");
			webStep.setWebStepName("input");
			webStep.setWindow(window);
			webStep.setFrame(frame);
			webStep.setElementID(elementId);
			webStep.setSelectBy(selectBy);
			webStep.setValue(inputValue);

		} else if (key.equals("click")) {
			String window = (String) webStepJsonObj.get("window");
			String selectBy = (String) webStepJsonObj.get("selectBy");
			String elementId = (String) webStepJsonObj.get("elementID");
			webStep.setWebStepName("click");
			webStep.setWindow(window);
			webStep.setElementID(elementId);
			webStep.setSelectBy(selectBy);

		} else if (key.equals("select")) {
			String frame = (String) webStepJsonObj.get("frame");
			String window = (String) webStepJsonObj.get("window");
			String selectBy = (String) webStepJsonObj.get("selectBy");
			String elementId = (String) webStepJsonObj.get("elementID");
			String inputValue = (String) webStepJsonObj.get("value");
			webStep.setWebStepName("select");
			webStep.setFrame(frame);
			webStep.setWindow(window);
			webStep.setElementID(elementId);
			webStep.setSelectBy(selectBy);
			webStep.setValue(inputValue);

		} else if (key.equals("waitForElement")) {
			String selectBy = (String) webStepJsonObj.get("selectBy");
			String elementId = (String) webStepJsonObj.get("elementID");
			webStep.setWebStepName("waitForElement");
			webStep.setElementID(elementId);
			webStep.setSelectBy(selectBy);

		} else if (key.equals("alert")) {
			String action = (String) webStepJsonObj.get("action");
			String inpValue = (String) webStepJsonObj.get("value");
			webStep.setWebStepName("alert");
			webStep.setAction(action);
			webStep.setValue(inpValue);

		} else if (key.equals("getValue")) {
			String frame = (String) webStepJsonObj.get("frame");
			String selectBy = (String) webStepJsonObj.get("selectBy");
			String elementId = (String) webStepJsonObj.get("elementID");
			String inputValue = (String) webStepJsonObj.get("value");
			webStep.setWebStepName("getValue");
			webStep.setFrame(frame);
			webStep.setElementID(elementId);
			webStep.setSelectBy(selectBy);
			webStep.setValue(inputValue);

		} else if (key.equals("assert")) {
			String alert = (String) webStepJsonObj.get("alert");
			String selectBy = (String) webStepJsonObj.get("selectBy");
			String elementId = (String) webStepJsonObj.get("elementID");
			String inputValue = (String) webStepJsonObj.get("value");
			webStep.setWebStepName("assert");
			webStep.setAlert(alert);
			webStep.setElementID(elementId);
			webStep.setSelectBy(selectBy);
			webStep.setValue(inputValue);

		} else if (key.equals("readValue")) {
			long row = (long) webStepJsonObj.get("row");
			long column = (long) webStepJsonObj.get("column");
			String value = (String) webStepJsonObj.get("value");
			webStep.setRow(row);
			webStep.setColumn(column);
			webStep.setValue(value);
		} else if (key.equals("browserclose")) {
			String window = (String) webStepJsonObj.get("window");
			String DriverClose = (String) webStepJsonObj.get("Close");
			webStep.setWebStepName("browserclose");
			webStep.setClose(DriverClose);
			webStep.setWindow(window);
		}

		return webStep;
	}

	private boolean isWebStep(String key, JSONObject stepObj) {

		boolean isWebStep = false;
		if (Arrays.asList(WEB_STEPS).contains(key.toUpperCase())) {
			isWebStep = true;
			if (key.equalsIgnoreCase("input")
					|| key.equalsIgnoreCase("getValue")
					|| key.equalsIgnoreCase("assert")
					|| key.equalsIgnoreCase("select")) {
				JSONObject testStepObj = (JSONObject) stepObj.get(key);
				String alert = (String) testStepObj.get("alert");
				String selectBy = (String) testStepObj.get("selectBy");
				String elementID = (String) testStepObj.get("elementID");
				String value = (String) testStepObj.get("value");
				if (null != selectBy && null != elementID && null != value) {
					isWebStep = true;
				} else if (null != alert && null != value) {
					isWebStep = true;
				}

				else {
					isWebStep = false;
				}
			}
		}
		return isWebStep;
	}

	private MainframeTestStep createMainframeSteps(String stepName,
			JSONObject testStepObj) {

		testStep = new MainframeTestStep();
		testStep.setStepName(stepName);
		testStep.setValue(AutomationUtils.getJsonElementValue(testStepObj,
				"value"));
		testStep.setKeyname(AutomationUtils.getJsonElementValue(testStepObj,
				"keyname"));
		testStep.setLabel(AutomationUtils.getJsonElementValue(testStepObj,
				"label"));
		testStep.setLabelPosition(AutomationUtils.getJsonElementValue(
				testStepObj, "position"));
		testStep.setOperator(AutomationUtils.getJsonElementValue(testStepObj,
				"operator"));

		testStep.setRow(AutomationUtils.getJsonElementLongValue(testStepObj,
				"row"));
		testStep.setColumn(AutomationUtils.getJsonElementLongValue(testStepObj,
				"column"));
		testStep.setTimeInMillis(AutomationUtils.getJsonElementLongValue(
				testStepObj, "timeInMillis"));
		testStep.setField_no(AutomationUtils.getJsonElementLongValue(
				testStepObj, "field"));
		testStep.setOffset(AutomationUtils.getJsonElementLongValue(testStepObj,
				"offset"));
		testStep.setLength(AutomationUtils.getJsonElementLongValue(testStepObj,
				"length"));
		testStep.setpRRSLValue(AutomationUtils.getJsonElementValue(testStepObj,
				"pRRSLValue"));
		testStep.setEncoded(AutomationUtils.getJsonElementBoolValue(
				testStepObj, "encoded"));
		return testStep;
		//
	}

	public void resolveCommonReferenceSteps() throws Exception {

		List<Step> testSteps_UpdatedWithRefSteps = new ArrayList<Step>();
		List<Step> testSteps_Parent = testCase.getTestSteps();

		// add existing all steps, this contains $ref steps also.
		testSteps_UpdatedWithRefSteps.addAll(testCase.getTestSteps());

		for (int currentPos = 0; currentPos < testSteps_Parent.size(); currentPos++) {
			MainframeTestStep mainframeTestStep = (MainframeTestStep) testSteps_Parent
					.get(currentPos);
			if (mainframeTestStep.getStepName().equalsIgnoreCase("$ref")) {
				List<Step> refSteps = getStepsFromCommonStepsFile(mainframeTestStep
						.getValue());
				testSteps_UpdatedWithRefSteps.addAll(currentPos + 1, refSteps);
			}
		}

		// update with correct location of refs file location after they are
		// resolved to be further removed.
		ArrayList<String> allRefPosition = new ArrayList<String>();
		for (int currentRow = 0; currentRow < testSteps_UpdatedWithRefSteps
				.size(); currentRow++) {
			MainframeTestStep mainframeTestStep = (MainframeTestStep) testSteps_UpdatedWithRefSteps
					.get(currentRow);
			if (mainframeTestStep.getStepName().equalsIgnoreCase("$ref")) {
				allRefPosition.add(mainframeTestStep.getValue());
			}
		}

		testCase.setTestSteps(removeRefLocationFromJsonStepFile(allRefPosition,
				testSteps_UpdatedWithRefSteps));
	}

	private List<Step> removeRefLocationFromJsonStepFile(
			ArrayList<String> allRefPosition,
			List<Step> testSteps_WithCommonRefSteps) {

		for (int refPos = 0; refPos < allRefPosition.size(); refPos++) {
			String refValue = allRefPosition.get(refPos);

			for (int currentPos = 0; currentPos < testSteps_WithCommonRefSteps
					.size(); currentPos++) {
				MainframeTestStep mainframeTestStep = (MainframeTestStep) testSteps_WithCommonRefSteps
						.get(currentPos);
				if (mainframeTestStep.getValue() == refValue) {
					testSteps_WithCommonRefSteps.remove(currentPos);
					break;
				}

			}
		}
		return testSteps_WithCommonRefSteps;
	}

	private List<Step> getStepsFromCommonStepsFile(String fileLocation)
			throws Exception {

		File fileCommonStep = new File(fileLocation);

		MainframeTestCase mainframeTestCaseCommonSteps = AutomationUtils
				.getMainframeTestCaseFromParser(fileCommonStep);
		return mainframeTestCaseCommonSteps.getTestSteps();

	}

	public HashMap<Integer, String> getCommonStepsElemetPosition() {

		return this.commonSteps;
	}
	
	/**
	 * Manual de-serialization of "data" test step in test case to TDMStep type.
	 * Extracts service-id and count from "filter" nested object and populates into TDMStep
	 * @param tdmStepJsonObj JSONObject representing the data test step
	 * @return Deserialised
	 * */
    private TDMStep getTdmStepFromJsonObj(JSONObject tdmStepJsonObj) {
    	log.debug("esi.automation.hub.framework.Parser -> getTdmStepFromJsonObj -> Begin Parsing Data step");
    	TDMStep tdmStep = new TDMStep();
    	
    	tdmStep.setName(AutomationUtils.getJsonElementValue(tdmStepJsonObj, "name"));
    	JSONObject tdmfilter = (JSONObject)tdmStepJsonObj.get("filter");
    	tdmStep.setTdmFilterPayload(tdmfilter);
    	tdmStep.setServiceId(AutomationUtils.getJsonElementValue(tdmfilter, "id"));
    	
    	long responseCount = AutomationUtils.getJsonElementLongValue(tdmfilter, "count");
    	tdmStep.setCount(responseCount);
    	log.debug("esi.automation.hub.framework.Parser -> getTdmStepFromJsonObj -> Parsing done Data step");
    	return tdmStep;
    }

}
