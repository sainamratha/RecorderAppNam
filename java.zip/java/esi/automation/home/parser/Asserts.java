package esi.automation.home.parser;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.Alert;

public class Asserts {

	static Logger log = Logger.getLogger(Asserts.class);

	public static boolean doAssert(String jsonLocator, String jsonLocValue,
			String Value, String strHighLight, int FinaSync, String alert)
			throws Exception {

		boolean blnIsElementExists = false;
		boolean blnStatusText = false;

		if (null != alert && !alert.isEmpty()) {
			Alert al = WebUtility.driver.switchTo().alert();
			String alText = al.getText();
			Assert.assertEquals(alText, Value);
			log.info("Expected Value : " + Value + " & Actual Value : "
					+ alText + " Assert Passed");
		} else {

			String strAssert = null;

			blnIsElementExists = WebUtility.ObjectExists(jsonLocator,
					jsonLocValue, strHighLight, FinaSync);
			if (blnIsElementExists) {
				strAssert = WebUtility.Element(jsonLocator, jsonLocValue)
						.getText();
				if (strAssert.isEmpty() || strAssert.length() == 0) {
					strAssert = WebUtility.Element(jsonLocator, jsonLocValue)
							.getAttribute("value");
				}

				if (Value.startsWith("$")) {
					String val = Value.substring(1, Value.length());
					String dValue = ValuePass.getDynamicValue(val);
					Assert.assertEquals(strAssert, dValue);
					log.info("Expected Value : " + dValue
							+ " & Actual Value : " + strAssert
							+ " Assert Passed");

				} else {
					Assert.assertEquals(strAssert, Value);
					log.info("Expected Value : " + Value + " & Actual Value : "
							+ strAssert + " Assert Passed");

				}

			}
		}

		return blnStatusText;

	}

}
