package esi.automation.home.parser;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileUtil {

    private static FileWriter fW;
    private static BufferedWriter bW;
    private static File f;
    private static FileReader fR;
    private static BufferedReader bR;
    private static String featureLine = null;
    private static String featureFileContent = "";
    private static final String gherkin_pattern = "\\{code:gherkin}(.*?)\\{code}";

    public static void createFeatureFile(String file, String content) throws Exception {

        try {
            f = new File(file);

            if (f.exists()) {
                f.delete();
            }

            fW = new FileWriter(f);
            bW = new BufferedWriter(fW);
            Pattern p = Pattern.compile(gherkin_pattern);
            Matcher m = p.matcher(content);
            while (m.find()) {
                featureFileContent = m.group(1);
            }
            if (featureFileContent.isEmpty())
                featureFileContent = content.substring(content.indexOf("{code:gherkin}") + 15,
                        content.indexOf("{code}") - 1);
            bW.write(featureFileContent);

        } catch (Exception e) {
            e.printStackTrace();
            throw (e);
        } finally {
            if (null != bW) {
                bW.close();
            }
            if (null != fW) {
                fW.close();
            }

        }

    }

    public static void createJavaFile(String file, String content) throws Exception {

        try {
            f = new File(file);

            if (f.exists()) {
                f.delete();
            }

            fW = new FileWriter(f);
            bW = new BufferedWriter(fW);
            bW.write(content);

        } catch (Exception e) {
            e.printStackTrace();
            throw (e);
        } finally {
            if (null != bW) {
                bW.close();
            }
            if (null != fW) {
                fW.close();
            }

        }

    }

    public static String readFeatureFile(String file) throws Exception {

        featureFileContent = "";
        boolean isGherkinStarted = false;
        try {
            f = new File(file);

            if (!f.exists()) {
                throw new IOException("File does not exist");
            }

            fR = new FileReader(f);
            bR = new BufferedReader(fR);

            while ((featureLine = bR.readLine()) != null) {
                if (!featureLine.isEmpty()) {
                    // if()
                    featureFileContent += (featureLine + "+");
                }
            }
            featureLine = null;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (null != fR)
                fR.close();
            if (null != bR)
                bR.close();
        }
        Pattern p = Pattern.compile(gherkin_pattern);
        Matcher m = p.matcher(featureFileContent);
        while (m.find()) {
            featureFileContent = m.group(1);
        }
        return featureFileContent;
    }

}
