package esi.automation.home.parser;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebUtility

{

	static Logger log = Logger.getLogger(WebUtility.class);
	public static WebDriver driver;
	public static String strException;
	static String driverPath;

	public static WebDriver Launch(String BrowserName, String url)
			throws Exception {

		switch (BrowserName.toLowerCase()) {
		case "chrome": {
			WebUtility.driver = Navigate.getChromeBrowser();
			break;
		}
		case "firefox": {
			WebUtility.driver = Navigate.getffBrowser();
			break;
		}
		case "headless": {
			WebUtility.driver = new HtmlUnitDriver();
			break;
		}
		case "ie": {
			WebUtility.driver = Navigate.getIEBrowser();
			break;
		}
		case "saucelabs": {
			WebUtility.driver = Navigate.getSauceLabs();
			break;
		}
		}

		WebUtility.driver.get(url);

		WebUtility.driver.manage().timeouts()
				.implicitlyWait(120, TimeUnit.SECONDS);
		WebUtility.driver.manage().timeouts()
				.pageLoadTimeout(120, TimeUnit.SECONDS);

		return WebUtility.driver;
	}

	public static boolean fluentWaitForElement(String jsonLocator,
			String jsonLocValue, int FinaSync) throws Exception {
		boolean blnWaitForElementExist = false;

		FluentWait<WebDriver> fwait = new FluentWait<WebDriver>(
				WebUtility.driver).withTimeout(FinaSync, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		for (int i = 0; i < 2; i++) {
			fwait.until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
					.executeScript("return document.readyState").equals(
							"complete"));
			fwait.until(ExpectedConditions
					.visibilityOfElementLocated(WebUtility.ElementLocator(
							jsonLocator, jsonLocValue)));

			blnWaitForElementExist = true;

		}
		return blnWaitForElementExist;
	}

	public static void highLighter(WebElement element) {
		final JavascriptExecutor jse = (JavascriptExecutor) WebUtility.driver;
		jse.executeScript("arguments[0].scrollIntoView(true);", element);
		jse.executeScript("arguments[0].style.border='2px solid blue'", element);
	}

	public static By ElementLocator(String JsonLocator, String jsonLocValue) {
		By by = null;

		switch (JsonLocator.toLowerCase()) {
		case "id": {
			by = By.id(jsonLocValue);
			break;
		}
		case "xpath": {
			by = By.xpath(jsonLocValue);
			break;
		}
		case "css": {
			by = By.cssSelector(jsonLocValue);
			break;
		}
		case "name": {
			by = By.name(jsonLocValue);
			break;
		}
		case "link": {
			by = By.linkText(jsonLocValue);
			break;
		}
		}
		return by;
	}

	public static WebElement Element(String JsonLocator, String jsonLocValue) {
		WebElement element = WebUtility.driver.findElement(WebUtility
				.ElementLocator(JsonLocator, jsonLocValue));
		return element;

	}

	public static List<WebElement> Elements(String JsonLocator,
			String jsonLocValue) {
		List<WebElement> element = WebUtility.driver.findElements(WebUtility
				.ElementLocator(JsonLocator, jsonLocValue));
		return element;
	}

	public static boolean ObjectExists(String JsonLocator, String jsonLocValue,
			String strHighLight, int FinaSync) throws Exception {

		boolean blnStatus = false;
		WebElement element_node = null;
		boolean blnDisplayed = false;
		fluentWaitForElement(JsonLocator, jsonLocValue, FinaSync);
		blnDisplayed = WebUtility.Element(JsonLocator, jsonLocValue)
				.isDisplayed();
		if (blnDisplayed) {
			element_node = WebUtility.Element(JsonLocator, jsonLocValue);

			blnStatus = true;
		}

		// blnStatus = false;

		if (strHighLight.equals("Yes"))
			highLighter(element_node);

		return blnStatus;
	}

	public static boolean Click(String jsonLocator, String jsonLocValue,
			String strHighLight, int FinaSync, String newWindow)
			throws Exception {
		if (null != newWindow && !newWindow.isEmpty())
			WebUtility.switchToSubwindow(newWindow);
		boolean blnIsElementExists = false;

		blnIsElementExists = ObjectExists(jsonLocator, jsonLocValue,
				strHighLight, FinaSync);
		if (blnIsElementExists) {
			WebUtility.Element(jsonLocator, jsonLocValue).click();
			// log.info("<<< Click Passed >>> Object " + jsonLocator + " : "
			// + jsonLocValue);

		} else {
			// log.info("<<< Click Failed >>> Object " + jsonLocator + " : "
			// + jsonLocValue);
		}

		return blnIsElementExists;
	}

	public static void alert(String value, String valName) {

		if (null != valName && !valName.isEmpty()) {
			if (value.equalsIgnoreCase("Enter")) {
				WebDriverWait wait = new WebDriverWait(WebUtility.driver, 15,
						1000);
				wait.until(ExpectedConditions.alertIsPresent());
				Alert al = WebUtility.driver.switchTo().alert();
				al.sendKeys(valName);
				al.accept();

			}
		}

		if (value.equalsIgnoreCase("Ok")) {
			WebDriverWait wait = new WebDriverWait(WebUtility.driver, 15, 1000);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert al = WebUtility.driver.switchTo().alert();
			al.accept();
			// log.info("<<< Clicked on Alert OK >>>");

		} else if (value.equalsIgnoreCase("Cancel")) {
			WebDriverWait wait = new WebDriverWait(WebUtility.driver, 15, 1000);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert al = WebUtility.driver.switchTo().alert();
			al.dismiss();

			// log.info("<<< Clicked on Alert OK >>>");
		}
	}

	public static void switchToFrame(String frameName) {

		WebUtility.driver.switchTo().frame(frameName);

	}

	public static boolean getValue(String frameName, String jsonLocator,
			String jsonLocValue, String key, String strHighLight, int FinaSync)
			throws Exception {

		boolean blnIsElementExists = false;
		String value = null;

		if (null != frameName && !frameName.isEmpty())
			WebUtility.driver.switchTo().frame(frameName);
		blnIsElementExists = ObjectExists(jsonLocator, jsonLocValue,
				strHighLight, FinaSync);
		if (blnIsElementExists) {
			value = WebUtility.Element(jsonLocator, jsonLocValue).getText();
			if (value.isEmpty() || value.length() == 0) {
				value = WebUtility.Element(jsonLocator, jsonLocValue)
						.getAttribute("value");
			}
			// log.info("<<< GetValue Operation Passed >>> GetValue key is :"
			// + key + " & Value fetched from the application is : "
			// + value);
			ValuePass.addValue(key, value);

		} else {
			// log.info("<<< GetValue Operation Failed >>> GetValue key is :"
			// + key + " & Value fetched from the application is : " +
			// value);
		}

		return blnIsElementExists;
	}

	public static boolean Input(String jsonLocator, String jsonLocValue,
			String Value, String strHighLight, int FinaSync, String frameName,
			String newWindow) throws Exception {
		if (null != frameName && !frameName.isEmpty())
			WebUtility.driver.switchTo().frame(frameName);

		if (null != newWindow && !newWindow.isEmpty())
			WebUtility.switchToSubwindow(newWindow);

		boolean blnIsElementExists = false;
		blnIsElementExists = ObjectExists(jsonLocator, jsonLocValue,
				strHighLight, FinaSync);
		if (blnIsElementExists) {
			// //log.info("<<< Input Operation Passed >>> Object for "+jsonLocator
			// + " : "+jsonLocValue);
			WebUtility.Element(jsonLocator, jsonLocValue).clear();

			if (Value.startsWith("$")) {
				String valueKey = Value.substring(1, Value.length());
				String dValue = ValuePass.getDynamicValue(valueKey);

				WebUtility.Element(jsonLocator, jsonLocValue).sendKeys(dValue);
				// log.info("<<< Input Passed >>> Object for " + jsonLocator
				// + ":" + jsonLocValue + " Value Passed : " + dValue);
			} else {
				WebUtility.Element(jsonLocator, jsonLocValue).sendKeys(Value);
				// log.info("<<< Input Passed >>> Object for " + jsonLocator
				// + ":" + jsonLocValue + " Value Passed : " + Value);
			}

		} else {
			// log.info("<<< Input Failed >>> Object for " + jsonLocator +
			// " : " + jsonLocValue);
		}

		return blnIsElementExists;
	}

	public static boolean Select(String jsonLocator, String jsonLocValue,
			String Value, String strHighLight, int FinaSync, String frameName,
			String newWindow) throws Exception {

		if (null != frameName && !frameName.isEmpty())
			WebUtility.driver.switchTo().frame(frameName);

		if (null != newWindow && !newWindow.isEmpty())
			WebUtility.switchToSubwindow(newWindow);

		boolean blnIsElementExists = false;

		blnIsElementExists = ObjectExists(jsonLocator, jsonLocValue,
				strHighLight, FinaSync);
		if (blnIsElementExists) {

			WebElement ele = WebUtility.Element(jsonLocator, jsonLocValue);
			Actions mouse = new Actions(WebUtility.driver);
			mouse.moveToElement(ele).click();
			mouse.build();
			mouse.perform();
			new Select(ele).selectByVisibleText(Value);

		}

		return blnIsElementExists;
	}

	public static FluentWait<WebDriver> fluentGeneralWait(int times) {

		FluentWait<WebDriver> fwait = new FluentWait<WebDriver>(
				WebUtility.driver).withTimeout(times, TimeUnit.SECONDS)
				.pollingEvery(100, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class, TimeoutException.class)
				.ignoring(StaleElementReferenceException.class);

		return fwait;
	}

	public static void switchToSubwindow(String switchToWin) throws Exception {

		final String prntWin = WebUtility.driver.getWindowHandle();

		if (switchToWin.equalsIgnoreCase("Yes")) {
			Thread.sleep(5000);
			Set<String> handles = WebUtility.driver.getWindowHandles();
			while (handles.size() <= 1) {
				handles = WebUtility.driver.getWindowHandles();
			}

			String subWin = null;

			Iterator<String> itr = handles.iterator();
			while (itr.hasNext()) {
				subWin = itr.next();
				if (!itr.hasNext()) {
					Thread.sleep(500);
					WebUtility.driver.switchTo().window(subWin);

				}

			}
		} else if (switchToWin.equalsIgnoreCase("No")) {
			WebUtility.driver.switchTo().window(prntWin);
		}

		Thread.sleep(500);

	}

	public static void KillProcess() throws Exception {

		Runtime.getRuntime().exec("TASKKILL /F /IM chromedriver.exe");
		Runtime.getRuntime().exec("TASKKILL /F /IM IEDriverServer.exe");

	}

	public static void driverClose(String close, String newWindow)
			throws Exception {
		if (null != newWindow && !newWindow.isEmpty()) {
			WebUtility.switchToSubwindow(newWindow);
		}
		WebUtility.driver.close();
		WebUtility.driver.quit();
		WebUtility.KillProcess();

	}

}
