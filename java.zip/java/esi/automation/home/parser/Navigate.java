package esi.automation.home.parser;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.apache.http.HttpHost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CommandInfo;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.HttpCommandExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.http.HttpClient.Factory;

public class Navigate {
	public static WebDriver driver;

	/*
	 * public static final String USERNAME = "qahub"; public static final String
	 * ACCESS_KEY = "053d3443-b0cf-41ef-997d-bf97afc16725"; public static final
	 * String URL = "http://" + USERNAME + ":" + ACCESS_KEY +
	 * "@ch3ar028399.express-scripts.com:4445"; public static final String
	 * Jenkins_URL =
	 * "http://"+System.getenv("SAUCE_USERNAME")+":"+System.getenv(
	 * "SAUCE_ACCESS_KEY")+"@ch3ar028399.express-scripts.com:4445";
	 */
	public static final String USERNAME = "ESI_Saucelabs";
	public static final String ACCESS_KEY = "443f4f70-10fb-43f9-8e79-d11bd887252a";
	public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY
			+ "@ondemand.saucelabs.com:443/wd/hub";

	public static String strException;
	static String driverPath;
	static {
		driverPath = System.getProperty("user.dir")
				+ "\\src\\main\\resources\\fixtures\\drivers\\";

	}

	public static WebDriver getIEBrowser() {
		DesiredCapabilities ieCap = DesiredCapabilities.internetExplorer();
		ieCap.setCapability(
				InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
				true);
		System.setProperty("webdriver.ie.driver", String.valueOf(driverPath)
				+ "IEDriverServer.exe");
		Navigate.driver = new InternetExplorerDriver(ieCap);
		return Navigate.driver;
	}

	public static WebDriver getChromeBrowser() {
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability("ensureCleanSession", true);
		System.setProperty("webdriver.chrome.driver",
				String.valueOf(driverPath) + "chromedriver.exe");
		Navigate.driver = new ChromeDriver();
		return Navigate.driver;
	}

	public static WebDriver getSauceLabs() {

		DesiredCapabilities ieCap = DesiredCapabilities.internetExplorer();

		ieCap.setCapability("platform", "Windows 10");
		ieCap.setCapability("version", "11.0");

		String proxyHost = "ps2devproxy.accounts.root.corp";
		int proxyPort = 8080;
		URL url;

		try {
			url = new URL(URL);
		} catch (MalformedURLException e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		HttpClientBuilder builder = HttpClientBuilder.create();
		HttpHost proxy = new HttpHost(proxyHost, proxyPort);
		builder.setProxy(proxy);

		Factory factory = new SauceClientFactory(builder);

		HttpCommandExecutor executor = new HttpCommandExecutor(
				new HashMap<String, CommandInfo>(), url, factory);

		Navigate.driver = new RemoteWebDriver(executor, ieCap);

		return Navigate.driver;
	}

	public static WebDriver getffBrowser() {

		System.setProperty("webdriver.gecko.driver", String.valueOf(driverPath)
				+ "geckodriver.exe");

		ProfilesIni prof = new ProfilesIni();
		FirefoxProfile firefoxProfile = prof.getProfile("default");
		firefoxProfile.setAcceptUntrustedCertificates(true);
		firefoxProfile.setAssumeUntrustedCertificateIssuer(false);

		Navigate.driver = new FirefoxDriver(firefoxProfile);

		return Navigate.driver;

	}

	public static void SauceLabs() {
		// Need a implementation
	}

}
