package esi.automation.home.parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.common.base.Stopwatch;
import com.jagacy.Field;
import com.jagacy.Key;
import com.jagacy.Session3270;
import com.jagacy.util.JagacyException;
import com.jagacy.util.JagacyProperties;
import com.jayway.jsonpath.JsonPath;

import esi.automation.home.model.EachStepResponseResult;
import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.MainframeTestStep;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.model.Step;
import esi.automation.home.model.TDMStep;
import esi.automation.home.model.WebStep;
import esi.automation.home.utils.AutomationUtils;
import esi.automation.home.utils.GrabScreenShots;
import esi.automation.hub.tdm.client.TDMClient;

public class Executer extends Session3270 {

	static Logger log = Logger.getLogger(Executer.class);

	private JagacyProperties props;
	ResourceBundle configuration = null;
	MainframeTestCase testCase = null;
	ExecuterWebStep executerWebStep = new ExecuterWebStep();

	List<Step> testSteps = null;
	List<EachStepResponseResult> responseResultList = new ArrayList<EachStepResponseResult>();
	HashMap<String, String> sessionData = new HashMap<String, String>();
	ResponseResult responseResult = new ResponseResult();
	boolean testResultfalied = false;
	long testduration;
	Properties properties = new Properties();
	String timeout = null;
	String testrunID = null;
	String failedTest = null;
	String delimiter = "|";

	private String userId;
	private String pwd;

	private boolean mfTestFailed = false;

	public Executer() throws JagacyException, IOException {

		super("Test Execution");
		// log.info("Begin loading properties");

		props = getProperties();
		loadProps();
		Enumeration<?> e = configuration.getKeys();
		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			String value = configuration.getString(key);
			props.set(key, value);
		}

	}

	public void getInstance(MainframeTestCase testCase) throws Exception {

		this.testCase = testCase;
		if (null == testCase)
			throw new Exception("stepList object is null");

		if (testCase.getScreenshot() != null
				&& testCase.getScreenshot().equalsIgnoreCase("on")) {
			props.set("window", "true");
		} else {
			props.set("window", "false");
		}

		if (testCase.getHost() != null) {
			props.set("jagacy.host", testCase.getHost());
		} else {
			throw new JagacyException(
					"Error Processing JSON Data, Host information incorrect !.");
		}

		if (testCase.getPort() != null) {
			props.set("jagacy.port", testCase.getPort());
		} else {
			throw new JagacyException(
					"Error Processing JSON Data, Port information incorrect !.");
		}

		if (null != testCase.getTdmUrl() && !testCase.getTdmUrl().isEmpty()) {
			props.set("tdm.url", testCase.getTdmUrl());
		} else {
			log.error("TDM URL not configured.");
			// throw new IOException("TDM URL not configured.");
		}

		// log.info("Get Property window - " + props.get("window"));
		// log.info("End loading properties");
		testSteps = testCase.getTestSteps();
	}

	public ResponseResult execute(String timeOut) throws JagacyException {
		this.timeout = timeOut;
		try {
			this.open();
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			this.close();
		}
		if (mfTestFailed) {
			this.open();
		}
		responseResult.setResponseResultList(responseResultList);
		responseResult.setSessionData(sessionData);
		if (testResultfalied) {
			log.info(delimiter + this.testCase.getApplication() + delimiter
					+ this.testCase.getPillar() + delimiter
					+ this.testCase.getEnvironment() + delimiter
					+ this.testCase.getBrowser() + delimiter + testduration
					+ delimiter + "Testcase_Failed" + delimiter + testrunID
					+ delimiter + this.testCase.getName() + delimiter
					+ failedTest);
		} else {
			log.info(delimiter + this.testCase.getApplication() + delimiter
					+ this.testCase.getPillar() + delimiter
					+ this.testCase.getEnvironment() + delimiter
					+ this.testCase.getBrowser() + delimiter + testduration
					+ delimiter + "Testcase_Passed" + delimiter + testrunID
					+ delimiter + this.testCase.getName() + delimiter
					+ "All Steps executed successfully");
		}
		return responseResult;
	}

	@Override
	protected boolean logon() throws JagacyException {

		if (mfTestFailed) {
			return mainframeLogoff();
		}
		String validationFaliure = null;
		int debugValue = 3; // this variable is only used during bebug mode
							// during step count.
		int fieldNumber = 0;
		int index = 0;
		int waitTime = Integer.parseInt(timeout);

		long start_time = System.currentTimeMillis();
		waitForChange(waitTime);
		testrunID = this.testCase.getName() + "_"
				+ this.testCase.getApplication() + "_" + start_time;

		for (Step step : this.testSteps) {
			try {
				String sessionKeyName = null;
				String sessionKeyValue = null;
				Field[] allFields = null;
				String testResult = Keywords.STEP_RESPONSE_RESULT_SUCCESS;

				index++;
				if (index == debugValue) {
					log.info("Debuging - Steps Number - " + index);
				}

				if (step instanceof WebStep) {

					WebStep webStep = (WebStep) step;
					log.info("Processing - Step - " + index + " Operations :"
							+ webStep.getWebStepName());

					EachStepResponseResult webStepResponseResult = executerWebStep
							.executeWebStep(index, testCase.getScreenshot(),
									sessionData, webStep);

					responseResultList.add(webStepResponseResult);
					if (webStepResponseResult.getResults().equalsIgnoreCase(
							Keywords.STEP_RESPONSE_RESULT_FAIL)) {
						break;
					}

				} else if (step instanceof TDMStep) {
					TDMStep tdmTestStep = (TDMStep) step;
					TDMClient tdmClient = new TDMClient();

					Stopwatch timer = Stopwatch.createStarted();
					JSONArray tdmResponse = tdmClient.getTestData(
							props.get("tdm.url"),
							tdmTestStep.getTdmFilterPayload());
					log.info("Processing - Step - " + index + " - "
							+ tdmTestStep.getName() + "TDM Call - "
							+ timer.stop() + " is the tme taken");

					tdmTestStep.setTdmResponse(tdmResponse);

					sessionData.put("$" + tdmTestStep.getName(),
							tdmResponse.toJSONString());
				} else {
					MainframeTestStep testStep = (MainframeTestStep) step;

					log.info("Processing - Step - " + index + " - "
							+ testStep.getStepName() + " Value - "
							+ testStep.getValue() + " * Label - "
							+ testStep.getLabel() + " * LabelPosition - "
							+ testStep.getLabelPosition()
							+ " * Co-ordinates - " + testStep.getRow() + "/"
							+ testStep.getColumn() + " * Key name - "
							+ testStep.getKeyname() + " * Wait time - "
							+ testStep.getTimeInMillis() + " * Field Number - "
							+ testStep.getField_no() + " " + testrunID);

					if (testStep.getValue() != null
							&& testStep.getValue().startsWith("$")) {
						if (testStep.getValue().contains("[")
								|| testStep.getValue().contains("]")) {
							log.debug("Executor -> logon: input step consuming response from TDM");
							String tdmResponsefromSessData = sessionData
									.get(testStep.getValue().substring(0,
											testStep.getValue().indexOf("[")));
							JSONParser parser = new JSONParser();
							JSONArray tdmResponsefromSessDataJSONObj = (JSONArray) parser
									.parse(tdmResponsefromSessData);

							String dotpath = testStep.getValue().substring(
									testStep.getValue().indexOf(".") + 1);
							int arrIndex = Integer
									.parseInt(testStep.getValue()
											.substring(
													testStep.getValue()
															.indexOf("[") + 1,
													testStep.getValue()
															.indexOf("]")));
							JSONObject jsontoconsiderforvalue = (JSONObject) tdmResponsefromSessDataJSONObj
									.get(arrIndex);

							String value = getJSONElementValue(
									jsontoconsiderforvalue, dotpath);
							testStep.setValue(value);

						} else {
							log.debug("Executor -> logon: input step consuming data from earlier step");
							testStep.setValue(sessionData.get(testStep
									.getValue()));
						}
					}

					try {
						Thread.currentThread();
						Thread.sleep(500);
					} catch (InterruptedException e) {
						validationFaliure = e.getLocalizedMessage();
					}

					switch (testStep.getType()) {

					case Keywords.TEST_STEP_WAIT_FOR_CORDINATE:

						props.set(("index" + index + ".wait.row"),
								Long.toString(testStep.getRow()));
						props.set(("index" + index + ".wait.column"),
								Long.toString(testStep.getColumn()));
						props.set(("index" + index + ".wait.value"),
								testStep.getValue());
						props.set(("index" + index + ".timeout.seconds"),
								Long.toString(testStep.getTimeInMillis()));
						try {
							Thread.currentThread();
							Thread.sleep(500);
						} catch (InterruptedException e) {
							validationFaliure = e.getLocalizedMessage();
						}
						waitForPosition("index" + index + ".wait", "index"
								+ index + ".timeout.seconds");
						break;

					case Keywords.TEST_STEP_WAIT_FOR_TIME:
						props.set("index" + index + ".timeout.seconds",
								Long.toString(testStep.getTimeInMillis()));
						waitForChange("index" + index + ".timeout.seconds");
						break;

					case Keywords.TEST_STEP_WRITE_AT_CORDINATE:

						props.set(("index" + index + ".entry.row"),
								Long.toString(testStep.getRow()));
						props.set(("index" + index + ".entry.column"),
								Long.toString(testStep.getColumn()));
						props.set(("index" + index + ".entry.value"),
								testStep.getValue());
						Field[] screenfields = readFields();
						int existingRwClmLength = 0;
						String existingValueforRwClmn = AutomationUtils
								.returnValueByLabel(screenfields,
										testStep.getLabel(),
										testStep.getColumn(),
										testStep.getRow(), null);
						if (existingValueforRwClmn != null) {
							existingRwClmLength = existingValueforRwClmn
									.length();
						}
						String testStepValue = testStep.getValue();
						int inputValLength = testStepValue.length();
						writePosition("index" + index + ".entry",
								testStep.getValue());
						if (existingRwClmLength != 0
								&& inputValLength < existingRwClmLength) {
							for (int i = 0; i < existingRwClmLength
									- inputValLength; i++) {
								writeKey(Key.DELETE);
							}
						}
						break;

					case Keywords.TEST_STEP_WRITE_AT_LABEL:
						if (testStep.getLabel().toLowerCase()
								.contains("userid")
								|| testStep.getLabel().toLowerCase()
										.contains("user-id")) {
							testStep.setValue(getUserId());
						}
						Field[] fields = readFields();
						int existingValueLength = 0;
						Long column = 0L;
						Long row = 0L;
						String existingValueforLabel = AutomationUtils
								.returnValueByLabel(fields,
										testStep.getLabel(), column, row,
										testStep.getLabelPosition());
						if (existingValueforLabel != null) {
							existingValueLength = existingValueforLabel
									.length();
						}

						String testStepVal = testStep.getValue();

						int inputValueLength = testStepVal.length();
						Field field = AutomationUtils.returnFieldByLabel(
								fields, testStep.getLabel());
						if (field != null && !field.isVisible()) {
							Boolean encoded = testStep.getEncoded();
							if (encoded != null && encoded == true) {

								testStep.setValue(AutomationUtils
										.decodePwd(getPwd()));
							} else {
								log.error("Password input in JSON should be encoded");
								testResultfalied = true;
								return false;
							}
						}

						if (testStep.getLabelPosition().equalsIgnoreCase(
								"after")) {
							if (testStep.getLabel().startsWith("%")
									&& testStep.getLabel().endsWith("%")) {
								writeAfterLabel(
										getFieldFullTextContains(testStep
												.getLabel()),
										testStep.getValue());
								if (existingValueLength != 0
										&& inputValueLength < existingValueLength) {
									for (int i = 0; i < existingValueLength
											- inputValueLength; i++) {
										writeKey(Key.DELETE);
									}
								}
							} else {
								writeAfterLabel(testStep.getLabel(),
										testStep.getValue());
								if (existingValueLength != 0
										&& inputValueLength < existingValueLength) {
									for (int i = 0; i < existingValueLength
											- inputValueLength; i++) {
										writeKey(Key.DELETE);
									}
								}
							}
						} else if (testStep.getLabelPosition()
								.equalsIgnoreCase("before")) {
							if (testStep.getLabel().startsWith("%")
									&& testStep.getLabel().endsWith("%")) {
								writeBeforeLabel(
										getFieldFullTextContains(testStep
												.getLabel()),
										testStep.getValue());
								if (existingValueLength != 0
										&& inputValueLength < existingValueLength) {
									for (int i = 0; i < existingValueLength
											- inputValueLength; i++) {
										writeKey(Key.DELETE);
									}
								}
							} else {
								writeBeforeLabel(testStep.getLabel(),
										testStep.getValue());
								if (existingValueLength != 0
										&& inputValueLength < existingValueLength) {
									for (int i = 0; i < existingValueLength
											- inputValueLength; i++) {
										writeKey(Key.DELETE);
									}
								}
							}
						} else {
							validationFaliure = "Position should be defined for writting after/before  label : "
									+ testStep.getValue();
							throw new JagacyException(
									"Position should be defined for writting after/before  label : "
											+ testStep.getValue());
						}
						break;

					case Keywords.TEST_STEP_WRITE_AT_FIELD:
						props.set(("index" + index + ".field"),
								Long.toString(testStep.getField_no()));
						props.set(("index" + index + ".offset"),
								Long.toString(testStep.getOffset()));
						props.set(("index" + index + ".length"),
								Long.toString(testStep.getLength()));
						writeField("index" + index, testStep.getValue());
						break;

					case Keywords.TEST_STEP_SEND_KEY_NAME:

						long getCRC32 = getCrc32();
						if (testStep.getKeyname().equalsIgnoreCase("ENTER")) {
							writeKey(Key.ENTER);
						} else if (testStep.getKeyname()
								.equalsIgnoreCase("PF5")) {
							writeKey(Key.PF5);
						} else if (testStep.getKeyname()
								.equalsIgnoreCase("PF3")) {
							writeKey(Key.PF3);
						} else if (testStep.getKeyname()
								.equalsIgnoreCase("PF8")) {
							writeKey(Key.PF8);
						} else if (testStep.getKeyname()
								.equalsIgnoreCase("PF9")) {
							writeKey(Key.PF9);
						} else if (testStep.getKeyname().equalsIgnoreCase(
								"PF10")) {
							writeKey(Key.PF10);
						} else if (testStep.getKeyname().equalsIgnoreCase(
								"PF11")) {
							writeKey(Key.PF11);
						} else if (testStep.getKeyname()
								.equalsIgnoreCase("PF4")) {
							writeKey(Key.PF4);
						}
						waitForNextScreen(getCRC32, waitTime);
						break;

					case Keywords.TEST_STEP_READ_AT_LABEL:
						allFields = readFields();

						sessionKeyName = "$" + testStep.getValue();
						fieldNumber = AutomationUtils.readFieldNumberByLabel(
								allFields, testStep.getLabel());

						if (testStep.getLabelPosition().equalsIgnoreCase(
								"before")
								&& fieldNumber > 0) {
							Long beforePosition = new Long(fieldNumber) - 1;
							sessionKeyValue = AutomationUtils
									.readFieldDataByFieldNumber(allFields,
											beforePosition);
						} else if (testStep.getLabelPosition()
								.equalsIgnoreCase("after") && fieldNumber > 0) {
							Long afterPosition = new Long(fieldNumber) + 1;
							sessionKeyValue = AutomationUtils
									.readFieldDataByFieldNumber(allFields,
											afterPosition);
						}
						sessionKeyValue = sessionData.put(sessionKeyName,
								sessionKeyValue);
						break;

					case Keywords.TEST_STEP_READ_AT_FIELDNUMBER:
						allFields = readFields();
						sessionKeyName = "$" + testStep.getValue();
						sessionKeyValue = AutomationUtils
								.readFieldDataByFieldNumber(allFields,
										testStep.getField_no());
						sessionData.put(sessionKeyName, sessionKeyValue);
						break;

					case Keywords.TEST_STEP_READ_AT_CORDINATE:
						String rowData = readRow(testStep.getRow().intValue());
						sessionKeyName = "$" + testStep.getValue();
						sessionKeyValue = rowData.substring(testStep
								.getColumn().intValue(), rowData.indexOf(" ",
								testStep.getColumn().intValue()));
						sessionData.put(sessionKeyName, sessionKeyValue);
						break;

					case Keywords.TEST_STEP_ADD_PRADD:
						boolean flag = false;
						boolean check;
						final int k = testStep.getRow().intValue();
						while (!flag) {
							check = true;
							int i = k;
							while (check) {
								testStep.setColumn(testStep.getColumn());
								testStep.setRow(new Long(i));
								String data = readRow(testStep.getRow()
										.intValue());
								if (data.isEmpty() || data.length() == 0
										|| data.split("-")[0].trim().isEmpty()) {
									check = false;
								}
								sessionKeyValue = data.split("-")[0].trim();
								if (sessionKeyValue.equalsIgnoreCase(testStep
										.getValue())) {

									// writeBeforeLabel(data.trim(), "x");

									testStep.setColumn(new Long(testStep
											.getColumn().intValue() - 2));
									testStep.setRow(new Long(i));
									testStep.setValue("x");
									props.set(("index" + index + ".entry.row"),
											Long.toString(testStep.getRow()));
									props.set(
											("index" + index + ".entry.column"),
											Long.toString(testStep.getColumn()));
									props.set(
											("index" + index + ".entry.value"),
											testStep.getValue());
									writePosition("index" + index + ".entry",
											testStep.getValue());

									props.set("index" + index
											+ ".timeout.seconds",
											Long.toString(5));
									waitForChange("index" + index
											+ ".timeout.seconds");

									check = false;
									flag = true;
									break;
								}
								i++;
							}

							if (flag) {
								break;
							}
							writeKey(Key.PF8);
							props.set("index" + index + ".timeout.seconds",
									Long.toString(5));
							waitForChange("index" + index + ".timeout.seconds");
						}

						writeKey(Key.ENTER);
						props.set("index" + index + ".timeout.seconds",
								Long.toString(5));
						waitForChange("index" + index + ".timeout.seconds");

						break;

					case Keywords.TEST_STEP_DEMO:
						boolean find = false;
						while (true) {
							for (int i = 2; i <= 10; i++) {
								testStep.setColumn(new Long(3));
								testStep.setRow(new Long(i));
								String data = readRow(testStep.getRow()
										.intValue());

								if (data.contains("-")) {
									sessionKeyValue = data.trim().split("-")[0]
											.trim();
								} else {
									sessionKeyValue = data.trim().split(" ")[0]
											.trim();
								}

								if (sessionKeyValue.equalsIgnoreCase(testStep
										.getpRRSLValue())) {

									testStep.setColumn(new Long(1));
									testStep.setRow(new Long(i));
									testStep.setValue("x");
									props.set(("index" + index + ".entry.row"),
											Long.toString(testStep.getRow()));
									props.set(
											("index" + index + ".entry.column"),
											Long.toString(testStep.getColumn()));
									props.set(
											("index" + index + ".entry.value"),
											testStep.getValue());
									writePosition("index" + index + ".entry",
											testStep.getValue());
									props.set("index" + index
											+ ".timeout.seconds",
											Long.toString(5));
									waitForChange("index" + index
											+ ".timeout.seconds");

									find = true;
									break;
								}
							}
							if (find) {
								break;
							}
							writeKey(Key.PF8);
							props.set("index" + index + ".timeout.seconds",
									Long.toString(5));
							waitForChange("index" + index + ".timeout.seconds");
						}

						writeKey(Key.ENTER);
						props.set("index" + index + ".timeout.seconds",
								Long.toString(5));
						waitForChange("index" + index + ".timeout.seconds");

						break;

					case Keywords.TEST_STEP_ASSERT_AT_CORDINATE:
						rowData = readRow(testStep.getRow().intValue());
						String screenData = rowData.substring(testStep
								.getColumn().intValue(), rowData.indexOf(" ",
								testStep.getColumn().intValue()));
						boolean negativeAssert = testStep.getOperator() != null
								&& testStep.getOperator().equals("not_equal");

						if (screenData.equals(testStep.getValue())
								&& !negativeAssert) {
							log.info("Assert - Step - " + index + " - "
									+ testStep.getStepName() + " id: "
									+ testStep.getStepId() + " Assert Value: "
									+ testStep.getValue()
									+ " Actual Value  Found: " + screenData
									+ " assert passed");
						} else if (!screenData.equals(testStep.getValue())
								&& negativeAssert) {
							log.info("Assert - Step - " + index + " - "
									+ testStep.getStepName() + " id: "
									+ testStep.getStepId() + " Assert Value: "
									+ testStep.getValue()
									+ " Actual Value  Found: " + screenData
									+ " assert passed");
						} else {
							log.info("Assert - Step - " + index + " - "
									+ testStep.getStepName() + " id: "
									+ testStep.getStepId() + " Assert Value: "
									+ testStep.getValue()
									+ " Actual Value  Found: " + screenData
									+ " assert failed");
							testResult = Keywords.STEP_RESPONSE_RESULT_FAIL;
						}
						break;
					case Keywords.TEST_STEP_ASSERT_AT_LABEL:
						allFields = readFields();
						negativeAssert = testStep.getOperator() != null
								&& testStep.getOperator().equals("not_equal");
						fieldNumber = AutomationUtils.readFieldNumberByLabel(
								allFields, testStep.getLabel());
						screenData = "";
						if (testStep.getLabelPosition().equalsIgnoreCase(
								"before")
								&& fieldNumber > 0) {
							Long beforePosition = new Long(fieldNumber) - 1;
							screenData = AutomationUtils
									.readFieldDataByFieldNumber(allFields,
											beforePosition);
						} else if (testStep.getLabelPosition()
								.equalsIgnoreCase("after") && fieldNumber > 0) {
							Long afterPosition = new Long(fieldNumber) + 1;
							screenData = AutomationUtils
									.readFieldDataByFieldNumber(allFields,
											afterPosition);
						}

						if (screenData.equals(testStep.getValue())
								&& !negativeAssert) {
							log.info("Assert - Step - " + index + " - "
									+ testStep.getStepName() + " id: "
									+ testStep.getStepId() + " Assert Value: "
									+ testStep.getValue()
									+ " Actual Value  Found: " + screenData
									+ " assert passed");
						} else if (!screenData.equals(testStep.getValue())
								&& negativeAssert) {
							log.info("Assert - Step - " + index + " - "
									+ testStep.getStepName() + " id: "
									+ testStep.getStepId() + " Assert Value: "
									+ testStep.getValue()
									+ " Actual Value  Found: " + screenData
									+ " assert passed");
						} else {
							log.info("Assert - Step - " + index + " - "
									+ testStep.getStepName() + " id: "
									+ testStep.getStepId() + " Assert Value: "
									+ testStep.getValue()
									+ " Actual Value  Found: " + screenData
									+ " assert failed");
							testResult = Keywords.STEP_RESPONSE_RESULT_FAIL;
						}
						break;
					case Keywords.TEST_STEP_ASSERT_AT_FIELDNUMBER:
						allFields = readFields();
						negativeAssert = testStep.getOperator() != null
								&& testStep.getOperator().equals("not_equal");
						screenData = AutomationUtils
								.readFieldDataByFieldNumber(allFields,
										testStep.getField_no());

						if (screenData.equals(testStep.getValue())
								&& !negativeAssert) {
							log.info("Assert - Step - " + index + " - "
									+ testStep.getStepName() + " id: "
									+ testStep.getStepId() + " Assert Value: "
									+ testStep.getValue()
									+ " Actual Value  Found: " + screenData
									+ " assert passed");
						} else if (!screenData.equals(testStep.getValue())
								&& negativeAssert) {
							log.info("Assert - Step - " + index + " - "
									+ testStep.getStepName() + " id: "
									+ testStep.getStepId() + " Assert Value: "
									+ testStep.getValue()
									+ " Actual Value  Found: " + screenData
									+ " assert passed");
						} else {
							log.info("Assert - Step - " + index + " - "
									+ testStep.getStepName() + " id: "
									+ testStep.getStepId() + " Assert Value: "
									+ testStep.getValue()
									+ " Actual Value  Found: " + screenData
									+ " assert failed");
							testResult = Keywords.STEP_RESPONSE_RESULT_FAIL;
						}
						break;
					default:
						validationFaliure = "Parameter Passed inside JSON is Incorrect, Step No/Name "
								+ index + " - " + testStep.getStepName();
						throw new IllegalArgumentException(validationFaliure);
					}

					String urlToScreenShot = null;

					if (testCase != null
							&& testCase.getScreenshot().equalsIgnoreCase("on")) {
						try {
							urlToScreenShot = GrabScreenShots
									.setScreenImage(index);
						} catch (Exception e) {
							responseResultList.add(AutomationUtils
									.getSingleStepResponseResult(
											Integer.toString(index),
											Keywords.STEP_RESPONSE_RESULT_FAIL,
											urlToScreenShot,
											e.getLocalizedMessage()));
							e.printStackTrace();
						}
					}
					responseResultList.add(AutomationUtils
							.getSingleStepResponseResult(
									Integer.toString(index), testResult,
									urlToScreenShot, null));
					if (Keywords.STEP_RESPONSE_RESULT_FAIL.equals(testResult)) {
						testResultfalied = true;
						failedTest = "Test Failed at Step - " + index
								+ ",Step name:" + testStep.getStepName()
								+ ",Assert Value: " + testStep.getValue();
						return true;
					}

				}
			} catch (Exception e) {
				e.printStackTrace();
				responseResultList.add(AutomationUtils
						.getSingleStepResponseResult(Integer.toString(index),
								Keywords.STEP_RESPONSE_RESULT_FAIL, "",
								e.getLocalizedMessage()));
				testResultfalied = true;
				if (e instanceof JagacyException) {
					mfTestFailed = true;
				}
				return false;
			}

			finally {
				long end_time = System.currentTimeMillis();
				testduration = end_time - start_time;
			}
		}

		/*
		 * long end_time = System.currentTimeMillis(); testduration =
		 * end_time-start_time;
		 */

		return true;
	}

	// Close jagacy processor terminal.
	@Override
	public void logoff() throws JagacyException {

		// this.close();

		// WebUtility.driverClose();
	}

	public void loadProps() throws IOException {

		configuration = ResourceBundle
				.getBundle("fixtures/jagacy/properties/jagacy");
	}

	private String getFieldFullTextContains(String value)
			throws JagacyException {

		String searchValue = value.replaceAll("%", " ").trim();
		Field field = null;
		Field[] fields = readFields();
		for (Field f : fields) {
			if (f.getValue().toUpperCase().contains(searchValue.toUpperCase())) {
				field = f;
			}
		}
		return field.getValue();
	}

	/**
	 * waiting for the next screen to get load. As soon as it is loaded, it will
	 * return. Maximum of 5 seconds it will wait for next screen to load and
	 * time is configurable. It is taking the wait time from property files.
	 * 
	 * @throws JagacyException
	 */
	private void waitForNextScreen(long crc32, int waitTime)
			throws JagacyException {

		boolean flag = false;

		do {
			long crcAfter = getCrc32();
			// checking for the loading the next screen, if previous screen
			// returns true, next is loaded , Otherwise false.
			if (crc32 == crcAfter) {
				// Successfully moved on to the next screen, breaking the loop
				waitForChange(waitTime);
				flag = true;
			} else {
				waitForChange(waitTime);
				flag = false;
				waitForChange(waitTime);
			}

		} while (flag == true);

	}

	/**
	 * Extraction of final value based on dot path present in the consuming test
	 * step. The dot path is based on response structure as published by TDM
	 * service catalog.
	 * 
	 * @param TDM
	 *            response object for consideration of final value to be
	 *            returned for input step
	 * @param dot
	 *            path present in the consuming test step of JSON test case
	 * @return final value as available from TDM response for the dot path
	 * 
	 **/
	private String getJSONElementValue(Object jsonObj, String keyArr) {
		log.debug("Executor -> getJSONElementValue for dot path: " + keyArr);
		String value = (String) JsonPath.read(jsonObj, "$." + keyArr);
		return value;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	private boolean mainframeLogoff() throws JagacyException {
		if (!isKeyboardUnlocked()) {
			waitForChange(5000);
		}
		props.set(("index" + 1 + ".entry.row"), "23");
		props.set(("index" + 1 + ".entry.column"), "18");
		try {
			writePosition("index" + 1 + ".entry", "b");
			writeKey(Key.ENTER);
			waitForChange(10000);
			props.set(("index" + 2 + ".entry.row"), "5");
			props.set(("index" + 2 + ".entry.column"), "29");
			writePosition("index" + 2 + ".entry", "Entry Validation");
			writeKey(Key.ENTER);
			waitForChange(50000);
			writeAfterLabel("Userid", getUserId());
			writeAfterLabel("Password", AutomationUtils.decodePwd(getPwd()));
			writeKey(Key.ENTER);
			waitForChange(50000);
			writeKey(Key.ENTER);
			waitForChange(50000);
			waitForChange(50000);
			waitForChange(50000);
			props.set(("index" + 3 + ".entry.row"), "22");
			props.set(("index" + 3 + ".entry.column"), "14");
			writePosition("index" + 3 + ".entry", "k all sgoff");
			writeKey(Key.ENTER);
			waitForChange(50000);
		} catch (Exception e) {
			e.printStackTrace();
			mfTestFailed = false;
			return false;
		}
		mfTestFailed = false;
		return false;
	}
}