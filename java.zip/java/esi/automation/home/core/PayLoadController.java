/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.core;

import java.util.Map;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.service.ProcessTestCaseService;
import esi.automation.home.utils.AutomationUtils;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */

@Controller
@RequestMapping("/process")
public class PayLoadController {

	static Logger log = Logger.getLogger(PayLoadController.class);

    @Autowired
    private ProcessTestCaseService processTestCaseService;
    
    @Value("${Timeout}")
	private String timeOut;

    @RequestMapping("/simple")
    public @ResponseBody String simple() {

        return "Hello world!";
    }

    @RequestMapping(value = "/string", method = RequestMethod.POST)
    public @ResponseBody String readString(@RequestBody String testString) {

        return "Read string '" + testString + "'" + "Current time is - " + AutomationUtils.getCurrentDateTime();
    }

    @RequestMapping(value = "/jsonstring", method = RequestMethod.POST, produces = "application/json")
    public @ResponseBody ResponseResult getJsonString(@RequestBody String jsonTestSteps) throws Exception {
    	log.info("the key values from the property file" + timeOut);
		return processTestCaseService.readAndExecuteSteps(jsonTestSteps,
				timeOut);
    }

    @RequestMapping(value = "/json", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    public @ResponseBody String readJson(@Valid @RequestBody MainframeTestCase mainframeTestCase) {

        log.info("Got name - " + mainframeTestCase.getName());
        log.info("Got curtor - " + mainframeTestCase.getCurator());
        log.info("Got mainframeTestCase String - " + mainframeTestCase.toString());

        return "Read from JSON: " + mainframeTestCase;
    }

    @RequestMapping(value = "/execute", method = RequestMethod.POST)
    public void process(@RequestBody Map<String, Object> payload) throws Exception {

        System.out.println(payload);

    }
    
    @RequestMapping(value = "/encode", method = RequestMethod.POST)
	public @ResponseBody String encode(@RequestBody String payload)
			throws Exception {
		return AutomationUtils.encodePwd(payload);
	}
}
