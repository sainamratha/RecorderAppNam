/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.utils;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class GrabScreenShots {

    static String LOCALSCREENSHOTPATH = "C:/esi/screens/";

    public static String setScreenImage(int stepNumber) throws Exception {

        String fileName = LOCALSCREENSHOTPATH + String.valueOf(stepNumber) + "_screenshot.png";
        BufferedImage image = new Robot()
                .createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        ImageIO.write(image, "png", new File(fileName));
        return fileName;
    }
}