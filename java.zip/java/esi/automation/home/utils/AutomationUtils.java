/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.utils;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.FileFileFilter;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.log4j.Logger;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.json.simple.JSONObject;

import com.jagacy.Field;
import com.jagacy.util.JagacyException;

import esi.automation.home.model.EachStepResponseResult;
import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.parser.Parser;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class AutomationUtils {

    static Logger log = Logger.getLogger(AutomationUtils.class);
    private static final String key="Yhqlh3oXnNiOIZQ/102C5A==";
    static final String REMOTE_URL = "https://git.express-scripts.com/ExpressScripts/test-automation-app.git";

    public static String getCurrentDateTime() {

        final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDateTime = dateFormat.format(new Date());
        return currentDateTime;
    }

    public static String getCurrentDateTimeHrsMillSec() {

        final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:sss");
        String currentDateTime = dateFormat.format(new Date());
        return currentDateTime;
    }

    public static void readScreenData(String[] readScreenData) throws JagacyException {

        log.info(" *********** Begin Printing Screen Data ************** ");
        int count = 0;
        for (String currentField : readScreenData) {

            log.info("Row Number : " + count + " : " + currentField.toString());
            count += 1;
        }
        log.info(" *********** End Printing Screen Data ************** ");

    }

    public static void readFieldData(Field[] allFields) throws JagacyException {

        log.info(" *********** Begin Printing Field Data ************** ");
        log.info("Total fields count - " + allFields.length);
        for (Field currentField : allFields) {
            log.info("RowNumber : " + currentField.getRow() + "--\n" + "Column Number : " + currentField.getColumn()
                    + "\n" + "FieldNumber : " + currentField.getFieldNumber() + "\n" + "Field Value : "
                    + currentField.getValue() + "\n" + "Field isModified : " + currentField.isModified() + "\n"
                    + "Field isNumeric : " + currentField.isNumeric() + "\n" + "Field isProtected : "
                    + currentField.isProtected() + "\n");
        }
        log.info(" *********** End Printing Field Data ************** ");

    }

    public static String readFieldDataByRowColumn(Field[] allFields, Long row, Long column) throws JagacyException {

        String data = null;
        for (Field currentField : allFields) {
            if (currentField.getColumn() == column && currentField.getRow() == row) {
                data = currentField.getValue();
                break;
            }
        }
        return data;
    }

    public static String readFieldDataByFieldNumber(Field[] allFields, Long fieldNumber) throws JagacyException {

        String data = null;
        for (Field currentField : allFields) {
            if (currentField.getFieldNumber() == fieldNumber) {
                data = currentField.getValue();
                break;
            }
        }
        return data;
    }

    public static int readFieldNumberByLabel(Field[] allFields, String label) throws JagacyException {

        int fieldNumber = 0;
        for (Field currentField : allFields) {
            if (currentField.getValue().toUpperCase().trim().contains(label.toUpperCase().trim())) {
                fieldNumber = currentField.getFieldNumber();
                break;
            }
        }
        return fieldNumber;
    }
    
    public static Field returnFieldByLabel(Field[] allFields, String label) throws JagacyException {

    	Field field = null;
        for (int i = 0; i < allFields.length; i++) {
            if (allFields[i].getValue().toUpperCase().trim().contains(label.toUpperCase().trim())) {
            	field = allFields[i+1];
                break;
            }
        }
        return field;
    }
    /**
     * @param allFields
     * @param label
     * @param column
     * @param row
     * @param position
     * @return
     * @throws JagacyException
     * 
     * This method returns the existing value of the particular label or row/column
     */
    public static String returnValueByLabel(Field[] allFields, String label, Long column, Long row, String position ) throws JagacyException {

    	String fieldValue = null;
    	Boolean finished= false;
    	for (int i = 0; i < allFields.length && !finished; i++) {
    		if(label !=null && position !=null && !label.isEmpty() && !position.isEmpty()){
    			if(position.equalsIgnoreCase("after")){
            if (allFields[i].getValue().trim().equals(label.trim())) {
            	fieldValue = allFields[i+1].getValue();
            	finished =true;
                break;
            }
    			}else{
    				if (allFields[i].getValue().trim().equals(label.trim())) {
    	            	fieldValue = allFields[i-1].getValue();
    	            	finished =true;
    	                break;
    	            }		
    			}
    		}else{
    			if (allFields[i].getColumn()== column.intValue() && allFields[i].getRow() == row.intValue() && !allFields[i].getValue().isEmpty()) {
                	fieldValue = allFields[i].getValue();
                	finished =true;
                    break;
                }
    			
    		}
            
        }
        return fieldValue;
    }
    public static String getJsonElementValue(JSONObject JSONObject, String elementName) {

        return (String) JSONObject.get(elementName);
    }

    public static Long getJsonElementLongValue(JSONObject JSONObject, String elementName) {

        return (Long) (JSONObject.get(elementName));
    }
    
    public static Boolean getJsonElementBoolValue(JSONObject JSONObject, String elementName) {

        return (Boolean) (JSONObject.get(elementName));
    }

    public static MainframeTestCase getMainframeTestCaseFromParser(File fileName) throws Exception {

        Parser testautomationParser = new Parser();

        MainframeTestCase mainframeTestCase = testautomationParser.parse(fileName);
        return mainframeTestCase;
    }
    
    public static EachStepResponseResult getSingleStepResponseResult(String runID, String executionResult,
            String urlToScreenShot, String validationFaliure) {

        EachStepResponseResult responseResult = new EachStepResponseResult();
        responseResult.setExecutionTime(AutomationUtils.getCurrentDateTimeHrsMillSec());
        responseResult.setResults(executionResult);
        responseResult.setRunID(runID);
        if (urlToScreenShot != null) {
            responseResult.setUrlToScreenShot(urlToScreenShot);
        }
        if (validationFaliure != null) {
            responseResult.setValidationFaliure(validationFaliure);
        }

        return responseResult;
    }
 
    public static String encodePwd(String pwd) throws Exception {
    	String bitBCDEncoded = "";
			byte[] keyBytes = Base64.decodeBase64(key);
			SecretKey originalKey = new SecretKeySpec(keyBytes, 0, keyBytes.length, "AES");
			Cipher AesCipher = Cipher.getInstance("AES");
			byte[] byteText = Base64.encodeBase64(pwd.getBytes());
			AesCipher.init(Cipher.ENCRYPT_MODE, originalKey);
			byte[] byteCipherText = AesCipher.doFinal(byteText);
			byte[] encodeAgain = Base64.encodeBase64(byteCipherText);
			bitBCDEncoded = new String(encodeAgain);
		
    	return bitBCDEncoded;
    }
    
    public static String decodePwd(String encodedPwd) throws Exception {
    	String actualPwdStr = "";
    		byte[] keyBytes = Base64.decodeBase64(key);
	    	byte[] byteText = Base64.decodeBase64(encodedPwd.getBytes());
	    	SecretKey originalKey = new SecretKeySpec(keyBytes, 0, keyBytes.length, "AES");
	    	Cipher AesCipher = Cipher.getInstance("AES");
	    	AesCipher.init(Cipher.DECRYPT_MODE, originalKey);
	        byte[] bytePwdText = AesCipher.doFinal(byteText);
	        byte[] actualPwdBytes = Base64.decodeBase64(bytePwdText);
	        actualPwdStr = new String(actualPwdBytes);
    	
    	return actualPwdStr;
    }
    
    
    /**
     * @param jsonFilePath
     * @param testMode
     * @throws Exception
     * commit json file into GIT Repo
     */
    public static void commitFileToGit(File jsonFilePath,boolean testMode) throws Exception{
		String userId="";
	    String password="";
        try{
       
         File localPath = new File(System.getProperty("user.home")+"/recorder/test-automation-app");
         if(localPath.isDirectory()){
        	 
        	 delete(new File(localPath.getAbsoluteFile().getParentFile().getAbsolutePath()));
        	 localPath.mkdir();
        	 
         }else{
        	 
        	 localPath.mkdir();
         }
         Git result = Git.cloneRepository()
                 .setURI(REMOTE_URL)
                 .setBranch("Feature/TTEQAN-134")
                 .setDirectory(localPath)
                 .setCredentialsProvider(new UsernamePasswordCredentialsProvider( userId, password) )
                 .call();
         log.info("Having repository: " + result.getRepository().getDirectory());
         log.info("Create a filter for .json files");
         // Create a filter for ".json" files
              IOFileFilter txtSuffixFilter = FileFilterUtils.suffixFileFilter(".json");
	          IOFileFilter txtFiles = FileFilterUtils.andFileFilter(FileFileFilter.FILE, txtSuffixFilter);
	
	     
	      // Create a filter for either directories or ".json" files
	           FileFilter filter = FileFilterUtils.orFileFilter(DirectoryFileFilter.DIRECTORY, txtFiles);

                // Copy using the filter
              FileUtils.copyDirectory(jsonFilePath, localPath, filter);
                
              File[] listOffiles= jsonFilePath.listFiles();
              if(testMode){
            	  if(listOffiles[0].getName().contains(".json")){
		              result.add()
		             .addFilepattern(listOffiles[0].getName())
		             .call();
            	  }
              }else{
              
              for(File file:listOffiles){
            	  
            	  if(file.getName().contains(".json")){
		              result.add()
		             .addFilepattern(file.getName())
		             .call();
            	  }
	             
              }
              }
             result.commit()
             .setMessage("recorder json file")
             .call();
             
            result.push().setCredentialsProvider(new UsernamePasswordCredentialsProvider( userId, password )).call();
            log.info("Committed file " + jsonFilePath.getName() + " to repository at " + localPath);
        }catch(Exception ex){
        	throw ex;
        }
    
   

           
}
	
	
	public static void delete(File file)
	    	throws IOException{

	    	if(file.isDirectory()){

	    		log.info("directory is empty, then delete it");
	    		if(file.list().length==0){
	    		   file.delete();
	    		   log.info("Directory is deleted : "   + file.getAbsolutePath());

	    		}else{

	    		   //list all the directory contents
	        	   String files[] = file.list();

	        	   for (String temp : files) {
	        	      //construct the file structure
	        	      File fileDelete = new File(file, temp);

	        	      //recursive delete
	        	     delete(fileDelete);
	        	   }

	        	   //check the directory again, if empty then delete it
	        	   if(file.list().length==0){
	           	     file.delete();
	           	  log.info("Directory is deleted : "    + file.getAbsolutePath());
	        	   }
	    		}

	    	}else{
	    		//if file, then delete it
	    		file.delete();
	    		 log.info("File is deleted : " + file.getAbsolutePath());
	    	}
	    }
	
	public static String numberCheck(String fieldValue){
		boolean isNumber = true;
		do {
			fieldValue = fieldValue.trim().replaceAll("^\\d+", "").trim();
				if (fieldValue.trim().matches("[0-9].*")) {
					isNumber = true;
				} else {
					isNumber = false;
				}
			
		} while (isNumber);
		return fieldValue;
	}
}
