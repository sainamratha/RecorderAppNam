package net.sf.f3270;

public enum MatchMode {
    EXACT, EXACT_AFTER_TRIM, REGEX, CONTAINS
}
