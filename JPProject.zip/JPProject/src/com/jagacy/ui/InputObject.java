package com.jagacy.ui;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


public class InputObject {
	
	private Map<String,String> input = new HashMap<String, String>();
	
	public Map<String, String> getinput() {
	        return Collections.unmodifiableMap(input);
	}
	
	public void addinput(String key, String value){
		input.put(key, value);
	}
	
}
