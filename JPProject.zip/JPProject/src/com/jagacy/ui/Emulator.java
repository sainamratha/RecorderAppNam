package com.jagacy.ui;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jagacy.AbstractSession;
import com.jagacy.Field;
import com.jagacy.Key;
import com.jagacy.Location;
import com.jagacy.Session3270;
import com.jagacy.util.I18n;
import com.jagacy.util.JagacyException;
import com.jagacy.util.LinkedHashMap;

/**
 * Implements a Patent session.
 * 
 * @author Robert M. Preston
 * 
 */
class JsonRecorder extends Session3270 {
    private UserInterface myUi;

    /**
     * Creates a Patent session.
     * 
     * @param name The session name (also the name of the .properties file).
     * @param ui The UI used to display the session.
     * @throws JagacyException If an error occurs.
     */
    JsonRecorder(String name, UserInterface ui) throws JagacyException {
        super(name, "mcfl1g05.medco.com", "IBM-3278-2");
        myUi = ui;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.Session3270#createUi()
     */
    protected UserInterface createUi() throws JagacyException {
        return myUi;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.AbstractSession#logon()
     */
    protected boolean logon() throws JagacyException {
        

        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.AbstractSession#logoff()
     */
    protected void logoff() throws JagacyException {
        if (logon()) {
            return;
        }
        
        writeKey(Key.PF3);
    }
}


public class Emulator extends AbstractSwing {

    private static final long serialVersionUID = 8831901593363366980L;

    private static final ImageIcon ICON = new ImageIcon(Emulator.class
        .getResource("book.jpg"));

    private LinkedHashMap myLookAndFeelMap = new LinkedHashMap();

    private boolean myIsCancelled;

    private AbstractSession mySession;

    /**
     * Creates the GUI.
     * 
     * @throws JagacyException If an error occurs.
     */
    private Emulator() throws JagacyException {
        super("JsonRecorder");

        UIManager.LookAndFeelInfo[] lafs = UIManager.getInstalledLookAndFeels();

        for (int i = 0; i < lafs.length; i++) {
            UIManager.LookAndFeelInfo laf = lafs[i];
            myLookAndFeelMap.put(laf.getName(), laf.getClassName());
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#createSession(java.lang.String)
     */
    protected AbstractSession createSession(String name) throws JagacyException {
        mySession = new JsonRecorder(name, this);
        return mySession;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#createPanel()
     */
    @Override
    protected AbstractPanel createPanel() throws JagacyException {
           return new Panel3270(this) {
               private static final long serialVersionUID = 299834078527771447L;
               Session3270 localSession32703 = (Session3270)getSession();
               
               public void processKey(KeyEvent paramKeyEvent) {
                super.processKey(paramKeyEvent);
                LinkedHashMap A=getKeyMap();
                KeyAction localKeyAction = (KeyAction)A.get(KeyStroke.getKeyStrokeForEvent(paramKeyEvent));
                try {
                if(localKeyAction!=null &&((localKeyAction.toString().equals("ENTER")))){
                	
				Location loc=localSession32703.readCursorLocation();
                captureEvents(loc,paramKeyEvent,localKeyAction);
              
               }
                }catch (JagacyException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                
               }
               
           };
       }





    public void captureEvents(Location L1, KeyEvent paramKeyEvent,KeyAction localKeyAction){
        try
        {
          Session3270 localSession3270 = (Session3270)getSession();

 		Location loc=localSession3270.readCursorLocation();
 		 Field[] arrayOfField=null;
 		 InputObject object=new InputObject() ;
 		 InputObject objectOne=new InputObject() ;
 		if(paramKeyEvent.getKeyCode()==10){
 	 //   System.out.println("the mouse location******"+loc.getColumn()+"the row position***"+loc.getRow()+"** the value*"+localKeyAction);
 		 arrayOfField = localSession3270.readFields();
 		Field field=null;
 		 for(int i=0;i<arrayOfField.length;i++){
 			 field=arrayOfField[i];
 			 if(field.isModified() && !field.getValue().trim().isEmpty()){
 				if(arrayOfField[i-1].isProtected()){
 					object.addinput("label", String.valueOf(arrayOfField[i-1].getValue().trim()));
					object.addinput("value", field.getValue().trim());
 				}else{
	 				object.addinput("row", String.valueOf(field.getRow()));
					object.addinput("column",String.valueOf(field.getColumn()));
					object.addinput("value", field.getValue().trim());
 				}
				
 			 }

 		 }
 		
 		 
 		    stepsToJson(object);	
 			if(localKeyAction.toString().equals("ENTER")){
 		    objectOne.addinput("keyname", localKeyAction.toString());
 		    stepsToJson(objectOne);	  	
 			}
   
        }
        } catch (JagacyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
      
 }
    
    public void stepsToJson(InputObject objectOne){
    	ObjectMapper mapper = new ObjectMapper();
    	mapper.enable(SerializationFeature.INDENT_OUTPUT);
    	 FileOutputStream outputStreamOne;
		try {
			outputStreamOne = new FileOutputStream("C:/Users/ec8038/Desktop/Jagacy.json", true);
		
			 JsonNode nodeOne = mapper.convertValue(objectOne, JsonNode.class);
		     mapper.writeValue(outputStreamOne, nodeOne);
		    
		   outputStreamOne.close(); 
		
		String jsonInStringOne = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(objectOne);
		System.out.println(jsonInStringOne);
		
		} catch (JsonGenerationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (JsonMappingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#getProductName()
     */
    protected String getProductName() {
        return "MyEmulator";
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#getIcon()
     */
    protected ImageIcon getIcon() {
        return ICON;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#connect()
     */
    protected boolean connect() {
        boolean connected = false;
        try {
            mySession.open();
            connected = true;
        } catch (JagacyException e) {
            AbstractSwing.printExceptions(e);
        }

        return connected;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#addMenu(javax.swing.JMenu)
     */
    protected JMenu addMenu(JMenu menu) {
        JMenu newMenu = null;
        if (menu.getActionCommand().equals(I18n.getText("gui.menu.edit"))) {
            newMenu = createMenu(I18n.getText("patents.options"), KeyEvent.VK_O);
            newMenu.add(createMenuItem(I18n.getText("patents.look_and_feel"),
                "Look and Feel", KeyEvent.VK_L));
        }
        return newMenu;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#addMenuItem(javax.swing.JMenuItem)
     */
    protected JMenuItem addMenuItem(JMenuItem menuItem) {
        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#addUserComponent(int)
     */
    protected JComponent addUserComponent(int index) {
        switch (index) {
        case 0:
            return getCursorComponent();
        case 1:
            return createEmptyComponent();
            // return getTimeComponent();
        case 2:
            return createEmptyComponent();
        }

        return null;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#addButton(javax.swing.JButton)
     */
    protected JButton addButton(JButton button) {
        JButton newButton = null;
        if (button.getActionCommand().equals("Paste")) {
            newButton = createButton(Emulator.class, "duke.gif",
                "Look and Feel", I18n.getText("patents.tip"));
        }
        return newButton;
    }

    /**
     * Implements the Look and Feel dialog box.
     */
    private void changeLookAndFeel() {
        myIsCancelled = false;
        final JDialog dialog = new JDialog(this, I18n.getText("patents.look_and_feel"), true);
        dialog.getContentPane().setLayout(new BorderLayout());
        dialog.setResizable(false);
        KeyAdapter finished = new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    dialog.setVisible(false);
                }
            }
        };
        JButton ok = new JButton(I18n.getText("gui.dialog.ok"));
        ok.setFont(CONTROL_FONT);
        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                dialog.setVisible(false);
            }
        });
        ok.addKeyListener(finished);

        JButton cancel = new JButton(I18n.getText("gui.dialog.cancel"));
        cancel.setFont(CONTROL_FONT);
        cancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                dialog.setVisible(false);
                myIsCancelled = true;
            }
        });

        JPanel panel = new JPanel();
        panel.add(Box.createHorizontalGlue());
        panel.add(ok);
        panel.add(cancel);
        panel.add(Box.createHorizontalGlue());
        dialog.getContentPane().add(panel, BorderLayout.SOUTH);

        panel = new JPanel();
        final JComboBox combo = new JComboBox();
        combo.setFont(CONTROL_FONT);
        for (Object key : myLookAndFeelMap.keySet()) {
            try {
                Class.forName((String)myLookAndFeelMap.get(key));
                combo.addItem(key);
            } catch (ClassNotFoundException e) {
            }
        }
        combo.setSelectedIndex(0);
        panel.add(combo);
        dialog.getContentPane().add(panel, BorderLayout.CENTER);

        ok.grabFocus();

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);

        if (myIsCancelled) {
            return;
        }

        try {
            UIManager.setLookAndFeel((String)myLookAndFeelMap.get(combo
                .getSelectedItem()));
            SwingUtilities.updateComponentTreeUI(this);
            pack();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.jagacy.ui.AbstractSwing#processAction(java.awt.event.ActionEvent)
     */
    protected boolean processAction(ActionEvent event) {
        boolean processed = false;
        String command = event.getActionCommand();
        if (command.startsWith("About ")) {
            JOptionPane.showMessageDialog(this, getProductName() + "\n"
                + "Copyright " + COPYRIGHT_SIGN_SYMBOL
                + " My Software.\nAll Rights Reserved.\n"
                + "(Portions copyright " + COPYRIGHT_SIGN_SYMBOL
                + " Jagacy Software)", "About " + getProductName(),
                JOptionPane.INFORMATION_MESSAGE, ICON);
            processed = true;
        } else if (command.equals("Look and Feel")) {
            changeLookAndFeel();
            processed = true;
        }
        return processed;
    }

    /**
     * Creates a specialized Swing GUI.
     * 
     * @param args Command line parameters.
     */
    public static void main(String[] args) {
        try {
            new Emulator();
        } catch (JagacyException e) {
            AbstractSwing.notify(new Swing3270(), ERROR_LEVEL,
                "MyEmulator Error", e.getMessage() + "\n");
            AbstractSwing.printExceptions(e);
            System.exit(1);
        }
    }
}
