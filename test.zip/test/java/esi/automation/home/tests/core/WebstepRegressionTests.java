package esi.automation.home.tests.core;

import static org.junit.Assert.assertTrue;

import java.io.File;

import org.apache.log4j.Logger;
import org.junit.Before;

import esi.automation.home.model.ResponseResult;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;

public class WebstepRegressionTests {

	ResponseResult responseResult = null;
	Executer executor = null;
	Parser parser = new Parser();
	static Logger log = Logger.getLogger(WebstepRegressionTests.class);

	@Before
	public void setup() throws Exception {
		executor = new Executer();
	}

	public void test_Chrome() throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		String chromeWebstepsJSON = "fixtures/jagacy/data/JsonWebstepRegression.json";
		File file = new File(classLoader.getResource(chromeWebstepsJSON)
				.getFile());

		executor.getInstance(parser.parse(file));
		responseResult = executor.execute("3000");
		assertTrue(responseResult.getResponseResultList().size() == 6);
	}

}
