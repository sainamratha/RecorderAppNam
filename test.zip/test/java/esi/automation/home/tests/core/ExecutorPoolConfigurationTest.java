package esi.automation.home.tests.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.Random;

import org.apache.commons.pool.impl.GenericObjectPool;
import org.springframework.aop.target.CommonsPoolTargetSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;

public class ExecutorPoolConfigurationTest {

	@Autowired
	ApplicationContext context;
	Executer executor;
	private static final int INITIAL_COUNT = 2;
	private int max = 0;
	String jsonForConnectionPooling = "fixtures/jagacy/data/JsonForConnectionPooling.json";
	String jsonLogoff = "fixtures/jagacy/data/JsonForConnectionPoolingLogoff.json";

	public void checkMaxSize() {
		CommonsPoolTargetSource targetSource = (CommonsPoolTargetSource) context
				.getBean("poolTargetSource");
		assertEquals(INITIAL_COUNT, targetSource.getMaxSize());
	}

	public void checkActiveConnections() throws Exception {
		CommonsPoolTargetSource targetSource = (CommonsPoolTargetSource) context
				.getBean("poolTargetSource");
		for (int i = 0; i < 2; i++) {
			targetSource.getTarget();
		}
		assertEquals(INITIAL_COUNT, targetSource.getActiveCount());
	}

	public void checkWhenExhausted() {
		CommonsPoolTargetSource targetSource = (CommonsPoolTargetSource) context
				.getBean("poolTargetSource");
		assertEquals(GenericObjectPool.WHEN_EXHAUSTED_BLOCK,
				targetSource.getWhenExhaustedAction());
	}

	public void checkPoolMaxWait() throws Exception {
		CommonsPoolTargetSource targetSource = (CommonsPoolTargetSource) context
				.getBean("poolTargetSource");
		targetSource.setMaxWait(10);
		targetSource.setWhenExhaustedAction((byte) 1);
		Executer[] list = new Executer[2];
		for (int i = 0; i < 2; i++) {
			list[i] = (Executer) targetSource.getTarget();
			list[i].getName();
		}
		try {
			targetSource.getTarget();
			fail("pool reached Max limit NoSuchElementException");
		} catch (NoSuchElementException e) {
		}
		targetSource.releaseTarget(list[1]);
		list[1] = (Executer) targetSource.getTarget();
	}

	public void checkExecuter() throws Exception {
		CommonsPoolTargetSource targetSource = (CommonsPoolTargetSource) context
				.getBean("poolTargetSource");
		targetSource.setMaxWait(10);
		Resource resource = context
				.getResource("classpath:/application.properties");
		Properties appPropertiesTest = PropertiesLoaderUtils
				.loadProperties(resource);
		Parser testautomationParser = new Parser();
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonForConnectionPooling)
				.getFile());
		MainframeTestCase testCase = testautomationParser.parse(file);
		Runnable runn = new Runnable() {

			@Override
			public void run() {
				try {
					ResponseResult responseResult = null;
					Executer exec = (Executer) targetSource.getTarget();
					if (exec.getUserId() == null && exec.getPwd() == null) {
						if (max == 0) {
							max = Integer.parseInt(appPropertiesTest
									.getProperty("genericIds.count"));
						}
						exec.setUserId(appPropertiesTest
								.getProperty("genericId." + max + ".userId"));
						exec.setPwd(appPropertiesTest.getProperty("genericId."
								+ max + ".pwd"));
						max--;
					}
					exec.getInstance(testCase);
					responseResult = exec.execute("3000");
					targetSource.releaseTarget(exec);
					assertEquals(responseResult.getResponseResultList().size(),
							19);
					responseResult = null;
				} catch (Exception e) {
				}
			}
		};
		for (int i = 0; i < 2; i++) {
			Thread t = new Thread(runn);
			if (i == 1) {
				Thread.currentThread();
				Thread.sleep(15000);
			}
			t.start();
		}
		try {
			executor = (Executer) targetSource.getTarget();
			if (executor.getUserId() == null && executor.getPwd() == null) {
				Random random = new Random();
				int min = 0;
				int val = random.nextInt(max - min) + min;
				executor.setUserId(appPropertiesTest.getProperty("genericId."
						+ val + ".userId"));
				executor.setPwd(appPropertiesTest.getProperty("genericId."
						+ val + ".pwd"));
			}
			executor.getInstance(testCase);
			ResponseResult responseResult = executor.execute("3000");
			assertEquals(responseResult.getResponseResultList().size(), 19);
		} catch (NoSuchElementException e) {
		}
	}

	public void checkLogoff() throws Exception {
		CommonsPoolTargetSource targetSource = (CommonsPoolTargetSource) context
				.getBean("poolTargetSource");
		targetSource.setMaxWait(10);
		Resource resource = context
				.getResource("classpath:/application.properties");
		Properties appPropertiesTest = PropertiesLoaderUtils
				.loadProperties(resource);
		Parser testautomationParser = new Parser();
		int max = Integer.parseInt(appPropertiesTest
				.getProperty("genericIds.count"));
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonLogoff).getFile());
		MainframeTestCase testCase = testautomationParser.parse(file);
		executor = (Executer) targetSource.getTarget();
		if (executor.getUserId() == null && executor.getPwd() == null) {
			Random random = new Random();
			int min = 0;
			int val = random.nextInt(max - min) + min;
			executor.setUserId(appPropertiesTest.getProperty("genericId." + val
					+ ".userId"));
			executor.setPwd(appPropertiesTest.getProperty("genericId." + val
					+ ".pwd"));
		}
		executor.getInstance(testCase);
		ResponseResult responseResult = executor.execute("3000");
		assertEquals(responseResult.getResponseResultList().size(), 15);
	}
}
