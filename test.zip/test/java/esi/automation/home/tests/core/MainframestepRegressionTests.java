package esi.automation.home.tests.core;

import static org.junit.Assert.assertTrue;

import java.io.File;

import org.apache.log4j.Logger;
import org.junit.Before;

import esi.automation.home.model.ResponseResult;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;

public class MainframestepRegressionTests {

	ResponseResult responseResult = null;
	Executer executor = null;
	Parser parser = new Parser();
	static Logger log = Logger.getLogger(MainframestepRegressionTests.class);

	@Before
	public void setup() throws Exception {
		executor = new Executer();
	}

	public void test_Mainframe() throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		String mainframeStepsJSON = "fixtures/jagacy/data/JsonMainframestepRegression.json";
		File file = new File(classLoader.getResource(mainframeStepsJSON)
				.getFile());

		executor.getInstance(parser.parse(file));
		responseResult = executor.execute("3000");
		assertTrue(responseResult.getResponseResultList().size() == 11);
	}

}
