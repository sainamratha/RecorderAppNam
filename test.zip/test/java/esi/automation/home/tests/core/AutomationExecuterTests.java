/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.tests.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.Before;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;
import esi.automation.home.utils.AutomationUtils;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class AutomationExecuterTests {

	/**
     * 
     */
	String jsonWithFewSteps = "fixtures/jagacy/data/JsonWithFewSteps.json";
	String jsonWithMultipleSteps = "fixtures/jagacy/data/JsonWithMultipleSteps.json";
	// TestCase2, JsonWithMultipleSteps, JsonStepsWithMultipleSteps.json";
	String jsonWithoutPassword = "fixtures/jagacy/data/JsonWithoutPassword.json";
	String recorderAppGeneratedJson_TC1 = "fixtures/jagacy/data/recorderAppGeneratedJson_TC1.json";
	String recorderAppGeneratedJson_TC2 = "fixtures/jagacy/data/recorderAppGeneratedJson_TC2.json";
	String jsonEncodedPassword = "fixtures/jagacy/data/JsonEncodedPassword.json";
	String jsonEncodedFalse = "fixtures/jagacy/data/JsonEncodedFalse.json";

	ResponseResult responseResult = null;
	Executer executor = null;
	Parser testautomationParser = new Parser();

	@Before
	public void setup() throws Exception {
		executor = new Executer();
	}

	public void givenValidInput_ExecuterRunWithSucess() throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithFewSteps)
				.getFile());
		executor.getInstance(testautomationParser.parse(file));
		responseResult = executor.execute("3000");
		assertTrue(responseResult.getResponseResultList().size() == 3);
	}

	public void test_ExecuterJsonMultipleSteps() throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithMultipleSteps)
				.getFile());
		MainframeTestCase testCase = testautomationParser.parse(file);
		executor.getInstance(testCase);
		responseResult = executor.execute("3000");
		assertEquals(responseResult.getResponseResultList().size(), 4);
	}

	public void test_ExecuterRecorderAppGeneratedJsonTC1_Success()
			throws Exception {

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(
				recorderAppGeneratedJson_TC1).getFile());

		MainframeTestCase testCase = testautomationParser.parse(file);
		executor.getInstance(testCase);
		responseResult = executor.execute("3000");
		assertEquals(responseResult.getResponseResultList().size(), 71);

	}

	public void test_ExecuterRecorderAppGeneratedJsonTC2_Success()
			throws Exception {

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(
				recorderAppGeneratedJson_TC2).getFile());

		MainframeTestCase testCase = testautomationParser.parse(file);
		executor.getInstance(testCase);
		responseResult = executor.execute("3000");
		assertEquals(responseResult.getResponseResultList().size(), 66);

	}

	public void test_TTEQAN28_ExecuterJsonBrowserElement() throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithMultipleSteps)
				.getFile());
		MainframeTestCase testCase = testautomationParser.parse(file);
		executor.getInstance(testCase);
		responseResult = executor.execute("3000");
		assertEquals(responseResult.getResponseResultList().size(), 4);
	}

	public void test_TTEQAN54_ExecuterJSONPasswordEncode() throws Exception {
		String pwdEncoded = AutomationUtils.encodePwd("AB1983ab");
		assertEquals("9toRCEcbyW3Pp3Do+zA6fA==", pwdEncoded);
	}

	public void test_TTEQAN54_ExecuterJSONPasswordDecode() throws Exception {
		String orgPwd = AutomationUtils.decodePwd("9toRCEcbyW3Pp3Do+zA6fA==");
		assertEquals("AB1983ab", orgPwd);
	}

	public void test_TTEQAN54_ExecuterJSONPwd() throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithoutPassword)
				.getFile());
		MainframeTestCase testCase = testautomationParser.parse(file);
		executor.getInstance(testCase);
		responseResult = executor.execute("3000");
		assertEquals(responseResult.getResponseResultList().size(), 8);
	}

	public void test_TTEQAN54_ExecuterUsingJSONCreatedByRecorderAppCheckEncodedingTrue()
			throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonEncodedPassword)
				.getFile());
		MainframeTestCase testCase = testautomationParser.parse(file);
		executor.getInstance(testCase);
		responseResult = executor.execute("3000");
		assertEquals(responseResult.getResponseResultList().size(), 19);
	}

	public void test_TTEQAN54_ExecuterUsingJSONCreatedByRecorderAppCheckEncodedingFalse()
			throws Exception {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonEncodedFalse)
				.getFile());
		MainframeTestCase testCase = testautomationParser.parse(file);
		executor.getInstance(testCase);
		responseResult = executor.execute("3000");
		assertEquals(responseResult.getResponseResultList().size(), 19);
	}

	public void test_TTEQAN134_numberCheck() {
		String fieldValue = "1234 12345 12 Drug NotFound 1234";
		String response = AutomationUtils.numberCheck(fieldValue);
		assertEquals("Drug NotFound 1234", response);
	}
}
