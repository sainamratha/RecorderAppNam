/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.tests.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.MainframeTestStep;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.model.Step;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;
import esi.automation.home.utils.AutomationUtils;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class AutomationParserTests {

	String jsonWithFewSteps = "fixtures/jagacy/data/JsonWithFewSteps.json";

	ResponseResult responseResult = null;
	Executer executor = null;
	Parser testautomationParser = new Parser();
	static Logger log = Logger.getLogger(AutomationParserTests.class);

	@Test
	public void givenValidInput_CheckParserCuratorElement() throws Exception {

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithFewSteps)
				.getFile());

		Parser parser = new Parser();
		MainframeTestCase testCase = parser.parse(file);
		assertTrue(testCase.getCurator() != null);

	}

	public void givenValidInput_CheckParserNameElement() throws Exception {

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithFewSteps)
				.getFile());

		Parser parser = new Parser();
		MainframeTestCase testCase = parser.parse(file);
		assertEquals(testCase.getName(), "NRX NewOrder Creation");

	}

	public void givenValidInput_CheckParserHostElement() throws Exception {

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithFewSteps)
				.getFile());

		Parser parser = new Parser();
		MainframeTestCase testCase = parser.parse(file);
		assertEquals(testCase.getHost(), "mcfl1g05.medco.com");

	}

	public void test_CheckParserJsonScreenShotElement() throws Exception {

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithFewSteps)
				.getFile());

		MainframeTestCase testCase = testautomationParser.parse(file);
		assertEquals(testCase.getScreenshot(), "on");

	}

	public void test_CheckParserJsonPortElement() throws Exception {

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithFewSteps)
				.getFile());

		MainframeTestCase testCase = testautomationParser.parse(file);
		assertEquals(testCase.getPort(), "23");

	}

	public void test_TTEQAN28_CheckParserJsonBrowserElement() throws Exception {

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithFewSteps)
				.getFile());

		MainframeTestCase testCase = testautomationParser.parse(file);
		assertEquals(testCase.getBrowser(), "ie");

	}

	public void test_TTEQAN28_CheckParserJsonDriverElement() throws Exception {

		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource(jsonWithFewSteps)
				.getFile());

		MainframeTestCase testCase = testautomationParser.parse(file);
		assertEquals(testCase.getDriver(), "jagacy");

	}

	public void test_TTEQAN49_AddCommonStepsToJsonMultipleFiles()
			throws Exception {

		// TODO
		// Add test how to get file from git -- this will be common step files.
		//

		String jsonWithCommonSteps_Parent = "C:/esi/ws/Git/git/test-automation-app/src/main/resources/fixtures/jagacy/data/JsonWithCommonStepsParent.json";
		String jsonWithCommonSteps_1 = "C:/esi/ws/Git/git/test-automation-app/src/main/resources/fixtures/jagacy/data/JsonWithCommonSteps_1.json";
		String jsonWithCommonSteps_2 = "C:/esi/ws/Git/git/test-automation-app/src/main/resources/fixtures/jagacy/data/JsonWithCommonSteps_2.json";

		File fileJsonWithCommonSteps_Parent = new File(
				jsonWithCommonSteps_Parent);
		File filejsonWithCommonSteps_1 = new File(jsonWithCommonSteps_1);
		File filejsonWithCommonSteps_2 = new File(jsonWithCommonSteps_2);

		MainframeTestCase mainframeTestCase_Parent = testautomationParser
				.parse(fileJsonWithCommonSteps_Parent);
		List<Step> testSteps_Parent = mainframeTestCase_Parent.getTestSteps();

		assertEquals(testSteps_Parent.size(), 5);
		log.info("Parent list has 5 elements :" + testSteps_Parent);

		HashMap<Integer, String> commonSteps = testautomationParser
				.getCommonStepsElemetPosition();
		assertEquals(commonSteps.size(), 2);
		log.info("Parent has 2 common step :" + commonSteps);

		MainframeTestCase mainframeTestCaseCommonSteps_1 = AutomationUtils
				.getMainframeTestCaseFromParser(filejsonWithCommonSteps_1);
		List<Step> testStepsCommonSteps_1 = mainframeTestCaseCommonSteps_1
				.getTestSteps();
		assertEquals(testStepsCommonSteps_1.size(), 1);
		log.info("Common Step 1 has 1 elements :" + testStepsCommonSteps_1);

		MainframeTestCase mainframeTestCaseCommonSteps_2 = AutomationUtils
				.getMainframeTestCaseFromParser(filejsonWithCommonSteps_2);
		List<Step> testStepsCommonSteps_2 = mainframeTestCaseCommonSteps_2
				.getTestSteps();
		assertEquals(testStepsCommonSteps_2.size(), 2);
		log.info("Common Step 2 has 2 elements :" + testStepsCommonSteps_2);

		List<Step> testSteps_UpdatedParent = new ArrayList<Step>();
		testSteps_UpdatedParent.addAll(testSteps_Parent);
		testSteps_UpdatedParent.addAll(4, testStepsCommonSteps_1);
		testSteps_UpdatedParent.addAll(6, testStepsCommonSteps_2);
		mainframeTestCase_Parent.setTestSteps(testSteps_UpdatedParent);
		assertEquals(testSteps_UpdatedParent.size(), 8);
		// log.info("Added Common steps to Parent has 8 elements :" +
		// testSteps_UpdatedParent);

		for (int i = 0; i < testSteps_UpdatedParent.size(); i++) {
			MainframeTestStep mainframeTestStep = (MainframeTestStep) testSteps_UpdatedParent
					.get(i);
			log.info("All Steps in Parent elements : " + i + " - "
					+ mainframeTestStep);
		}

	}

	public void test_TTEQAN49_AddCommonStepsToJson() throws Exception {

		String jsonWithCommonSteps_Parent = "C:/esi/ws/Git/git/test-automation-app/src/main/resources/fixtures/jagacy/data/JsonWithCommonStepsParent.json";
		File fileJsonWithCommonSteps_Parent = new File(
				jsonWithCommonSteps_Parent);
		MainframeTestCase mainframeTestCase_Parent = testautomationParser
				.parse(fileJsonWithCommonSteps_Parent);
		List<Step> testSteps_Parent = mainframeTestCase_Parent.getTestSteps();
		assertEquals(testSteps_Parent.size(), 7);

		for (int i = 0; i < testSteps_Parent.size(); i++) {
			MainframeTestStep mainframeTestStep = (MainframeTestStep) testSteps_Parent
					.get(i);
			log.info("All Steps in Parent elements : " + i + " - "
					+ mainframeTestStep);
		}

		//
	}

}
