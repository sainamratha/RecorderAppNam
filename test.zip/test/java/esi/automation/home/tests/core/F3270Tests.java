/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.tests.core;

import static org.junit.Assert.assertEquals;

import java.io.File;

import org.junit.Test;

import esi.automation.hub.framework.TestClient;
import esi.automation.hub.framework.TestResult;

public class F3270Tests {

    String jsonWithMultipleTestSteps = "fixtures/jagacy/data/JsonStepsForF3270.json";
    
    public void givenValidInputRun_TestCaseClientLocalUsingJSON() throws Exception {

    	ClassLoader classLoader = getClass().getClassLoader();
        TestClient mainframeClientJson = new TestClient();
        File file = new File(classLoader.getResource(jsonWithMultipleTestSteps).getFile());
        TestResult testResult = mainframeClientJson.runTest(file);
        assertEquals(testResult.getResponseResultList().size(), 85);
    }

}
