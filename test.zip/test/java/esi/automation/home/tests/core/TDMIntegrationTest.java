/**
 * 
 */
package esi.automation.home.tests.core;

import static org.junit.Assert.*;
import org.junit.Test;

import esi.automation.home.mainframe.MainframeClientLocalUsingJSON;
import esi.automation.home.model.ResponseResult;
/**
 * @author EH2966
 *
 */
public class TDMIntegrationTest {
	String jsonWithTDMTestSteps = "fixtures/jagacy/data/TDM_TC25.json";

	//@Test
    public void givenValidInputRun_MainframeClientLocalTDMJSON() throws Exception {

        MainframeClientLocalUsingJSON mainframeClientJson = new MainframeClientLocalUsingJSON();
        ResponseResult responseResult = mainframeClientJson.readAndExecuteSteps(jsonWithTDMTestSteps);
        assertTrue(responseResult.getResponseResultList().size() > 0);
    }
}
