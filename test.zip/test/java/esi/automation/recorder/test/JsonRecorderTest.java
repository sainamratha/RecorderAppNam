package esi.automation.recorder.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.jagacy.ui.UserInterface;

import esi.automation.home.utils.AutomationUtils;
import esi.automation.recorder.InputObject;
import esi.automation.recorder.JsonList;
import esi.automation.recorder.JsonRecorder;

/**
 * @author EC7352
 *
 */
public class JsonRecorderTest {

	
	 private String jsonSteps = "fixtures/jagacy/data";
	 
	public void jsonFileTestcases() throws Exception {
		stepsToJson_Failure();
		stepsToJsonFileContent_Success();

	}

	JsonList jsonList = new JsonList();
	UserInterface ui;

	public void stepsToJson_Failure() throws Exception {
		JsonRecorder recorderOne = new JsonRecorder("JsonSteps", ui, jsonList);
		List<InputObject> listInputObjects = null;
		InputObject object = new InputObject();
		object.addinput("label", "ENTER HERE  ====>");
		object.addinput("position", "after");
		object.addinput("value", "b");
		recorderOne.stepsToJson(listInputObjects);
		String fileName = new SimpleDateFormat("yyyyMMddHHmm'.json'")
				.format(new Date());
		File file = new File(fileName);
		// assertTrue(!file.exists());

	}

	public void jsonRecorder_CommittoGit_returnSuccess() throws Exception{
		 ClassLoader classLoader = getClass().getClassLoader();
	        File file = new File(classLoader.getResource(jsonSteps).getFile());
		AutomationUtils.commitFileToGit(file,true);
		
	}
	
	public void stepsToJson_Success() throws Exception {
		JsonRecorder recorderOne = new JsonRecorder("JsonSteps", ui, jsonList);
		List<InputObject> listInputObjects = new ArrayList<InputObject>();
		InputObject object = new InputObject();
		object.addinput("label", "ENTER HERE  ====>");
		object.addinput("position", "after");
		object.addinput("value", "b");
		listInputObjects.add(object);
		recorderOne.stepsToJson(listInputObjects);
		String fileName = new SimpleDateFormat("yyyyMMddHHmm'.json'")
				.format(new Date());
		File file = new File(fileName);
		assertTrue(file.exists());

	}

	public void stepsToJsonFileContent_Success() throws Exception {
		JsonRecorder recorderOne = new JsonRecorder("JsonSteps", ui, jsonList);
		List<InputObject> listInputObjects = new ArrayList<InputObject>();
		InputObject object = new InputObject();
		object.addinput("label", "ENTER HERE  ====>");
		object.addinput("position", "after");
		object.addinput("value", "b");
		listInputObjects.add(object);
		recorderOne.stepsToJson(listInputObjects);
		String fileName = new SimpleDateFormat("yyyyMMddHHmm'.json'")
				.format(new Date());
		File file = new File(fileName);
		StringBuilder result = new StringBuilder();
		org.apache.commons.io.LineIterator it = org.apache.commons.io.FileUtils
				.lineIterator(file);
		try {
			while (it.hasNext()) {
				String line = it.nextLine();
				result.append("{").append(line).append("}");
			}
		} finally {
			it.close();
		}
		JSONParser parser = new JSONParser();
		JSONArray a = (JSONArray) parser.parse(new FileReader(fileName));
		String label = null;
		List<String> jsonValues = new ArrayList<String>();
		for (Object o : a) {
			JSONObject obj = (JSONObject) o;
			label = obj.toJSONString();
			jsonValues.add(label);
		}
		assertNotNull(jsonValues.get(0));

		assertEquals(
				"{\"input\":{\"label\":\"ENTER HERE  ====>\",\"position\":\"after\",\"value\":\"b\"}}",
				jsonValues.get(0));
	}

}
